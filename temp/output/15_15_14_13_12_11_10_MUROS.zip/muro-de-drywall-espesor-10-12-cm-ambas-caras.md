##  Muro de Drywall, Espesor 10-12 cm, Ambas Caras 

###  Definición 

La actividad consiste en la construcción de muros interiores utilizando paneles de yeso laminado, conocidos como drywall, con un espesor de 10 a 12 centímetros en cada cara. Estos muros se utilizan comúnmente en proyectos de construcción residencial, comercial e industrial debido a su rapidez de instalación, versatilidad y acabado liso. 

###  Materiales, Equipos y Herramientas 

  * Paneles de yeso laminado (drywall) de 10-12mm de espesor. 
  * Perfiles de acero galvanizado para estructura (montantes y canales). 
  * Cintas de papel y pasta para juntas. 
  * Tornillos para drywall. 
  * Material de aislamiento acústico y/o térmico (opcional). 
  * Material de limpieza y protección para el acabado final del muro. 
  * Taladro atornillador. 
  * Sierra circular o sierra caladora. 
  * Llave de impacto. 
  * Cuchilla para cortar el drywall. 
  * Espátula para aplicación de pasta de juntas. 
  * Nivel láser o nivel de burbuja. 
  * Equipos de protección personal (EPP) incluyendo guantes, gafas de seguridad, mascarilla y casco. 
  * Instaladores de drywall con experiencia en el montaje y acabado de paneles. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento 

El proceso de construcción del muro de drywall con un espesor de 10-12 centímetros en ambas caras se llevará a cabo de la siguiente manera: 

Se procederá a limpiar y nivelar el área donde se instalará el muro de drywall, asegurando una base sólida y libre de humedad que permita una correcta fijación de los perfiles de acero galvanizado. 

Se fijarán los perfiles de acero galvanizado a las paredes y al techo, siguiendo el diseño y las dimensiones especificadas en los planos del proyecto. Se utilizará el taladro atornillador y la llave de impacto para asegurar los perfiles en su lugar. 

Se cortarán los paneles de drywall a la medida requerida utilizando la sierra circular o la sierra caladora. Los paneles se fijarán a los perfiles de acero utilizando tornillos para drywall, asegurando una correcta alineación y nivelación con el nivel láser o el nivel de burbuja. 

Se aplicará cinta de papel y pasta para juntas en las uniones entre los paneles de drywall, asegurando una superficie lisa y uniforme. Se utilizará la espátula para aplicar la pasta de juntas y para eliminar los excesos, asegurando un acabado de alta calidad. 

Una vez secada la pasta de juntas, se procederá a lijar las superficies para obtener un acabado suave y uniforme. Se aplicará una capa de pintura o revestimiento según las especificaciones del proyecto, asegurando un aspecto final estético y duradero. 

Realizar una inspección detallada de la estructura de soporte antes de la instalación del drywall para asegurar su integridad y capacidad de carga. 

Utilizar herramientas de corte y fijación adecuadas para evitar daños en los paneles de drywall y garantizar una instalación precisa y segura. 

###  Medición y forma de pago 

Para medir y pagar la actividad de construcción de muro de drywall con un espesor de 10-12 centímetros en ambas caras, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de superficie del muro construido en todos los predios durante la ejecución del proyecto. Esto incluirá todas las caras del muro, independientemente de su forma o dimensiones específicas, tomando en cuenta su longitud y altura. 

La medición considerará la cantidad de metros cuadrados de superficie construida del muro de drywall, teniendo en cuenta la complejidad del diseño y las características del área donde se encuentre. Se tomará en consideración tanto el área de las paredes como de los techos donde se instale el drywall. 

El pago se efectuará según la cantidad de metros cuadrados de muro de drywall construido, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A., asegurando que se cumplan los estándares de calidad y las especificaciones técnicas definidas en el proyecto. 
