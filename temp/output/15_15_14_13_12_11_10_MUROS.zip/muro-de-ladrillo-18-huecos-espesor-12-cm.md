##  Muro de Ladrillo 18 Huecos, Espesor 12 cm 

###  Definición 

La actividad consiste en la construcción de un muro de ladrillo con una altura de 18 huecos y un espesor de 12 centímetros. Este tipo de muro se utiliza para fines estructurales y de división en proyectos de construcción. 

###  Materiales, Equipos y Herramientas 

  * Ladrillos 18h. 
  * Mortero de cemento para la unión de los ladrillos. 
  * Arena limpia y de granulometría adecuada para la preparación del mortero. 
  * Agua limpia y potable para la mezcla del mortero. 
  * Material de limpieza y protección para el acabado final del muro. 
  * Paleta y llana para la aplicación del mortero. 
  * Nivel de burbuja para la alineación y nivelación del muro. 
  * Cinta métrica y regla metálica para la medición y marcado. 
  * Equipos de protección personal (EPP) incluyendo guantes, gafas de seguridad, casco y botas de seguridad. 
  * Albañiles con experiencia en la construcción de muros de ladrillo. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento 

El proceso de construcción del muro de ladrillo 18H con un espesor de 12 centímetros se llevará a cabo de la siguiente manera: 

Se procederá a limpiar y nivelar el área donde se construirá el muro, asegurando una base estable y libre de obstáculos que puedan interferir con la construcción. 

Se preparará el mortero de cemento mezclando adecuadamente el cemento, la arena y el agua en las proporciones especificadas. Se recomienda utilizar una mezcladora para obtener una mezcla homogénea y de buena consistencia. 

Se procederá a la colocación de los ladrillos sobre una cama de mortero, asegurando una correcta disposición y alineación de estos. Se utilizará el nivel de burbuja para verificar la verticalidad y la horizontalidad del muro durante la construcción. 

Se aplicará mortero entre los ladrillos para unirlos entre sí, formando una estructura sólida y continua. Se utilizará la paleta y la llana para distribuir el mortero de manera uniforme y para eliminar los excesos. 

Se considerará la incorporación de refuerzos verticales y horizontales, así como de anclajes metálicos, para mejorar la estabilidad y resistencia del muro, especialmente en zonas sujetas a cargas estructurales elevadas o a condiciones climáticas adversas. 

Una vez completada la construcción del muro, se procederá a limpiar cualquier exceso de mortero y a realizar un acabado final en las juntas entre los ladrillos para mejorar la estética y la resistencia del muro. 

###  Medición y forma de pago 

Para medir y pagar la actividad de construcción de muro de ladrillo 18H con un espesor de 12 centímetros, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de superficie del muro construido en todos los predios durante la ejecución del proyecto. Esto incluirá todas las caras del muro, independientemente de su forma o dimensiones específicas, tomando en cuenta su longitud y altura. 

La medición considerará la cantidad de metros cuadrados de superficie construida del muro de ladrillo, teniendo en cuenta la complejidad del diseño y las características del terreno donde se encuentre. Se incluirán tanto las secciones rectas como las curvas del muro. 

El pago se efectuará según la cantidad de metros cuadrados de muro de ladrillo construido, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A., asegurando que se cumplan los estándares de calidad y las especificaciones técnicas definidas en el proyecto. 
