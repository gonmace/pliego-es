##  Sobrecimientos de Hormigón Ciclópeo 

###  Definición 

La actividad de construcción de sobrecimientos de hormigón armado comprende la ejecución de elementos estructurales que se sitúan sobre la cimentación y sirven de base para la estructura de la edificación. Estos sobrecimientos son fundamentales para distribuir las cargas de la superestructura de manera uniforme sobre la cimentación y para proporcionar un nivel adecuado de resistencia y estabilidad a la edificación. 

###  Materiales, Equipos y Herramientas 

  * Hormigón premezclado de calidad estructural. 
  * Armaduras de acero (varillas, mallas, estribos, etc.). 
  * Encofrado de madera o metálico. 
  * Desencofrante. 
  * Aditivos para hormigón (si es necesario). 
  * Material de limpieza y curado del hormigón. 
  * Mezcladora de hormigón. 
  * Vibradores de hormigón. 
  * Herramientas de corte y doblado de armaduras. 
  * Equipos de elevación y transporte de materiales. 
  * Herramientas manuales de albañilería. 
  * Equipos de protección personal (EPP) incluyendo casco, guantes, botas de seguridad, y protección ocular. 
  * Ingeniero civil o arquitecto responsable de la dirección técnica. 
  * Personal especializado en la colocación y vibrado del hormigón. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento 

Se realizará la limpieza y nivelación del terreno sobre el cual se construirán los sobrecimientos, asegurando una base firme y estable para la ejecución de los trabajos. 

Se procederá a la instalación del encofrado, el cual definirá la forma y dimensiones de los sobrecimientos. El encofrado deberá ser adecuadamente nivelado, fijado y apuntalado para resistir la presión del hormigón fresco. 

Se colocarán las armaduras de acero dentro del encofrado de acuerdo con el diseño estructural, asegurando la correcta posición, separación y solape entre las barras. Se prestará especial atención a las zonas de mayor carga y a los detalles constructivos. 

Se preparará el hormigón premezclado en la mezcladora, asegurando la adecuada proporción de cemento, agregados y agua. El hormigón será transportado y vertido en el encofrado mediante equipos adecuados, evitando la segregación y garantizando una distribución homogénea. 

Se procederá a compactar y vibrar el hormigón fresco con vibradores de alta frecuencia, asegurando la eliminación de posibles bolsas de aire y la completa llenado de los espacios entre las armaduras. Este proceso garantizará la densidad y resistencia del hormigón endurecido. 

Una vez que el hormigón haya alcanzado la resistencia suficiente, se procederá al desencofrado de los sobrecimientos. Posteriormente, se realizará el curado del hormigón mediante la aplicación de productos específicos o mediante métodos de curado húmedo, asegurando su adecuado fraguado y endurecimiento. 

Se recomienda realizar un adecuado control de calidad durante todas las etapas del proceso, incluyendo la selección de materiales, la preparación del terreno, la colocación de armaduras y la ejecución del hormigón, para garantizar la conformidad con los requisitos del proyecto y las normativas aplicables. 

###  Medición y forma de pago 

Para medir y pagar la actividad de construcción de sobrecimientos de hormigón armado, la unidad de medida será el metro cúbico (m³). Se calculará el volumen total de hormigón utilizado en la construcción de los sobrecimientos realizados en todos los predios durante la ejecución del proyecto. Esto incluirá todas las áreas cubiertas por los sobrecimientos, independientemente de su forma o dimensiones específicas. 

La medición considerará la cantidad de hormigón vertido en los encofrados de los sobrecimientos, teniendo en cuenta la complejidad del diseño y las características del terreno. Se realizarán estimaciones precisas del volumen de hormigón necesario para cada sobrecimiento, considerando la profundidad, el ancho y la longitud de estos. 

El pago se efectuará según el volumen de hormigón utilizado en la construcción de los sobrecimientos, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A., asegurando que se cumplan los estándares de calidad y las especificaciones técnicas definidas en el proyecto. 
