##  Placa de Drywall 

###  Definición 

La actividad consiste en la instalación o cambio de placas de drywall en estructuras interiores, ya sea para la creación de nuevas divisiones o para la reparación y renovación de paredes y techos existentes. El drywall, también conocido como placa de yeso laminado, es un material versátil y ligero utilizado en la construcción de interiores debido a su facilidad de instalación y acabado. 

###  Materiales, Equipos y Herramientas 

  * Placas de drywall de espesor adecuado. 
  * Tornillos para drywall. 
  * Cinta para juntas de drywall. 
  * Pasta o compuesto para juntas de drywall. 
  * Material de acabado final (pintura, revestimiento, etc.). 
  * Taladro atornillador. 
  * Llave de impacto. 
  * Sierra circular o sierra caladora. 
  * Espátula para aplicación de pasta de juntas. 
  * Cuchilla para cortar el drywall. 
  * Nivel de burbuja. 
  * Equipos de protección personal (EPP) incluyendo guantes, gafas de seguridad, mascarilla y casco. 
  * Instaladores de drywall con experiencia en la manipulación y montaje de placas. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento 

El proceso de instalación o cambio de placas de drywall se llevará a cabo de la siguiente manera: 

Se procederá a limpiar y preparar el área donde se realizará la instalación o el cambio de placas de drywall. Se verificará que la estructura de soporte esté en buenas condiciones y se tomarán las medidas necesarias para proteger el área circundante. 

Se medirá el área a cubrir con las placas de drywall y se cortarán las placas según las dimensiones necesarias utilizando una sierra circular o una sierra caladora. Se asegurará un corte preciso y limpio para facilitar su instalación. 

Se fijarán las placas de drywall a la estructura de soporte utilizando tornillos para drywall, asegurando una distribución uniforme y un adecuado espaciado entre tornillos. Se utilizará el taladro atornillador y la llave de impacto para realizar la fijación de manera eficiente. 

Se aplicará cinta para juntas de drywall en las uniones entre las placas, seguido de la aplicación de pasta o compuesto para juntas. Se utilizará una espátula para aplicar la pasta de manera uniforme y para eliminar los excesos, asegurando un acabado suave y sin irregularidades. 

Una vez secada la pasta de juntas, se procederá a lijar las superficies para obtener un acabado suave y uniforme. Se aplicará el acabado final deseado, ya sea pintura, revestimiento u otro material según las especificaciones del proyecto. 

###  Medición y forma de pago 

Para medir y pagar la actividad de instalación o cambio de placa de drywall, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de superficie cubierta por la instalación o reemplazo de placas de drywall realizada en todos los ambientes durante la ejecución del proyecto. Esto incluirá todas las áreas donde se realice la instalación o reemplazo, independientemente de su forma o dimensiones específicas. 

La medición considerará la cantidad de metros cuadrados de superficie cubierta por las placas de drywall instaladas o reemplazadas, teniendo en cuenta la complejidad del diseño, los recortes necesarios y la cantidad de placas utilizadas. 

El pago se efectuará según la cantidad de metros cuadrados de instalación o reemplazo de placas de drywall realizado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A., asegurando que se cumplan los estándares de calidad y las especificaciones técnicas definidas en el proyecto. 
