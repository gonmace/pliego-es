##  Muro de Ladrillo 6 Huecos, Espesor 10 cm 

###  Definición 

La actividad de construcción de un muro de ladrillo 6H, con un espesor de 10 centímetros, implica la edificación de una estructura de contención o división utilizando ladrillos cerámicos o de arcilla cocida. Este tipo de muro se caracteriza por su resistencia, durabilidad y capacidad de soportar cargas verticales y horizontales, siendo comúnmente utilizado en proyectos de viviendas, edificios comerciales e industriales. 

###  Materiales, Equipos y Herramientas 

  * Ladrillos 6H. 
  * Mortero de cemento para la unión de los ladrillos. 
  * Arena limpia y de granulometría adecuada para la preparación del mortero. 
  * Material de limpieza y protección para el acabado final del muro. 
  * Paleta y llana para la aplicación del mortero. 
  * Nivel de burbuja para la alineación y nivelación del muro. 
  * Cinta métrica y regla metálica para la medición y marcado. 
  * Cortadora de ladrillos para realizar cortes necesarios. 
  * Equipos de protección personal (EPP) incluyendo guantes, gafas de seguridad, casco y botas de seguridad. 
  * Albañiles con experiencia en la construcción de muros de ladrillo. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento: 

El proceso de construcción del muro de ladrillo 6H con un espesor de 10 centímetros se llevará a cabo de la siguiente manera: 

Se procederá a limpiar y nivelar el área donde se construirá el muro, asegurando una base estable y libre de obstáculos que puedan interferir con la construcción. 

Se preparará el mortero de cemento mezclando adecuadamente el cemento, la arena y el agua en las proporciones especificadas. Se recomienda utilizar una mezcladora para obtener una mezcla homogénea y de buena consistencia. 

Se procederá a la colocación de los ladrillos sobre una cama de mortero, asegurando una correcta disposición y alineación de estos. Se utilizará el nivel de burbuja para verificar la verticalidad y la horizontalidad del muro durante la construcción. 

Se aplicará mortero entre los ladrillos para unirlos entre sí, formando una estructura sólida y continua. Se utilizará la paleta y la llana para distribuir el mortero de manera uniforme y para eliminar los excesos. 

En caso de ser necesario, se realizarán cortes en los ladrillos para ajustar su tamaño y forma a las necesidades del diseño del muro. Se utilizará una cortadora de ladrillos para obtener cortes limpios y precisos. 

Una vez completada la construcción del muro, se procederá a limpiar cualquier exceso de mortero y a realizar un acabado final en las juntas entre los ladrillos para mejorar la estética y la resistencia del muro. 

Se debe implementar técnicas de juntas de dilatación para permitir la expansión y contracción del muro debido a cambios de temperatura y humedad, evitando la aparición de grietas y fisuras. 

###  Medición y forma de pago 

Para medir y pagar la actividad de construcción de muro de ladrillo 6H con un espesor de 15 centímetros, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de superficie del muro construido en todos los predios durante la ejecución del proyecto. Esto incluirá todas las caras del muro, independientemente de su forma o dimensiones específicas, tomando en cuenta su longitud y altura. 

La medición se realizará tomando en consideración la cantidad de metros cuadrados de superficie construida del muro de ladrillo, teniendo en cuenta la complejidad del diseño y las características del terreno donde se encuentre. 

El pago se efectuará según la cantidad de metros cuadrados de muro de ladrillo construido, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A., asegurando que se cumplan los estándares de calidad y las especificaciones técnicas definidas en el proyecto. 
