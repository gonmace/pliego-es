##  Impermeabilización de Sobrecimientos con Polipropileno 

###  Definición 

La actividad de impermeabilización de sobrecimientos con polipropileno consiste en aplicar un sistema de impermeabilización adecuado para proteger los sobrecimientos de edificaciones contra la infiltración de agua y humedad. Este proceso es fundamental para garantizar la durabilidad y la integridad estructural de los sobrecimientos, evitando problemas como la aparición de humedades, filtraciones y daños por corrosión en las armaduras. 

###  Materiales, Equipos y Herramientas 

  * Membrana de polipropileno para impermeabilización. 
  * Sellador de juntas y grietas. 
  * Adhesivo para fijación de la membrana. 
  * Primer para preparación de la superficie. 
  * Material de refuerzo para esquinas y detalles. 
  * Geotextil para protección mecánica. 
  * Elementos de fijación (tornillos, clavos, etc.). 
  * Material de sellado para encuentros con otros elementos constructivos. 
  * Pistola de calor para soldadura de la membrana. 
  * Rodillo de aplicación para asegurar la correcta adhesión. 
  * Espátulas y llanas para aplicación de adhesivos y selladores. 
  * Brochas y cepillos para la preparación de la superficie. 
  * Herramientas manuales y eléctricas para corte y manipulación de materiales. 
  * Equipos de protección personal (EPP) incluyendo guantes, gafas de seguridad, y cascos. 
  * Arquitectos o ingenieros especializados en impermeabilización. 
  * Personal técnico cualificado para la instalación y supervisión. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento 

Se procederá a limpiar y preparar la superficie de los sobrecimientos, eliminando cualquier suciedad, restos de mortero o pintura, y asegurando que la superficie esté completamente seca y libre de humedad. Se aplicará un primer adecuado para mejorar la adherencia de la membrana. 

Se procederá a desplegar y fijar la membrana de polipropileno sobre la superficie preparada, asegurando que quede correctamente alineada y sin arrugas. Las juntas entre láminas se sellarán con el adhesivo correspondiente y se aplicará calor con la pistola para soldar las uniones y garantizar la estanqueidad. 

Se prestará especial atención a los detalles constructivos, como las esquinas, encuentros con otros elementos estructurales y penetraciones, los cuales serán reforzados con material adicional y sellados con los productos adecuados para garantizar la continuidad del sistema de impermeabilización. 

Se colocará un geotextil sobre la membrana como protección mecánica, asegurando que quede correctamente fijado y protegiendo la impermeabilización de posibles daños durante el proceso constructivo y la vida útil del edificio. 

Una vez finalizada la instalación, se realizará una inspección visual para verificar la correcta ejecución del trabajo y se llevarán a cabo pruebas de estanqueidad para asegurar que no existan fugas o defectos en el sistema de impermeabilización. 

Se debe considerar la aplicación de un sistema de drenaje en caso de que existan problemas de acumulación de agua en los sobrecimientos. 

Realizar un adecuado control de calidad durante todas las etapas del proceso, incluyendo la selección de materiales, la preparación de la superficie y la instalación de la membrana, para asegurar la correcta ejecución del trabajo y evitar futuros problemas de humedad y filtraciones. 

###  Medición y forma de pago 

Para medir y pagar la actividad de impermeabilización de sobrecimientos con polipropileno, la unidad de medida será el metro lineal (ml). Se calculará la longitud total cubierta por la impermeabilización realizada en todos los sobrecimientos durante la ejecución del proyecto. Esto incluirá todas las longitudes impermeabilizadas con precisión utilizando los materiales y procedimientos especificados, abarcando la totalidad de los sobrecimientos en las ubicaciones mencionadas anteriormente, independientemente de su forma o dimensiones específicas. La medición considerará la cantidad de metros lineales impermeabilizados, teniendo en cuenta la longitud total cubierta y la complejidad de los sobrecimientos. Se tendrán en cuenta aspectos como las esquinas, bordes irregulares y cualquier otra característica que pueda influir en la cantidad de material y trabajo requerido para una impermeabilización adecuada. El pago se efectuará según la cantidad de metros lineales de impermeabilización realizados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de la entidad contratante, asegurando que se cumplan los estándares de calidad y durabilidad especificados en el proyecto. 
