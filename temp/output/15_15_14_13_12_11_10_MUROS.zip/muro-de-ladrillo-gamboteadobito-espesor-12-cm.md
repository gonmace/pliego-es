##  Muro de Ladrillo Gambote/Adobito, Espesor 12 cm 

###  Definición 

La actividad consiste en la construcción de un muro utilizando ladrillos gambote o adobitos, con un espesor de 12 centímetros. Este tipo de muro se caracteriza por su aspecto rústico y su resistencia, siendo comúnmente utilizado en construcciones tradicionales y proyectos de restauración arquitectónica. 

###  Materiales, Equipos y Herramientas: 

  * Ladrillos gambote o adobitos. 
  * Mortero de barro o tierra para la unión de los ladrillos. 
  * Paja o fibras vegetales para mejorar la cohesión del mortero. 
  * Material de limpieza y protección para el acabado final del muro. 
  * Paleta y llana de albañil para la aplicación del mortero. 
  * Nivel de burbuja para la alineación y nivelación del muro. 
  * Cinta métrica y regla metálica para la medición y marcado. 
  * Equipos de protección personal (EPP) incluyendo guantes, gafas de seguridad, y botas de seguridad. 
  * Albañiles con experiencia en la construcción de muros de ladrillo gambote. 
  * Ayudantes de obra para apoyo logístico y manipulación de materiales. 



###  Procedimiento 

El proceso de construcción del muro de ladrillo gambote o adobito con un espesor de 12 centímetros se llevará a cabo de la siguiente manera: 

Se procederá a limpiar y nivelar el área donde se construirá el muro, asegurando una base estable y libre de obstáculos que puedan interferir con la construcción. 

Se preparará el mortero de barro o tierra, mezclándolo con agua hasta obtener una consistencia adecuada para la aplicación. Se recomienda agregar paja o fibras vegetales al mortero para mejorar su cohesión y resistencia. 

Se procederá a la colocación de los ladrillos gambote o adobitos sobre una capa de mortero, asegurando una correcta disposición y alineación de estos. Se utilizará el nivel de burbuja para verificar la verticalidad y la horizontalidad del muro durante la construcción. 

Se aplicará el mortero entre los ladrillos para unirlos entre sí, formando una estructura sólida y continua. Se utilizará la paleta y la llana de albañil para distribuir el mortero de manera uniforme y para eliminar los excesos. 

Una vez completada la construcción del muro, se procederá a limpiar cualquier exceso de mortero y a realizar un acabado final en las juntas entre los ladrillos para mejorar la estética y la resistencia del muro. 

Se debe implementar técnicas de impermeabilización para proteger el muro de la humedad y la erosión, especialmente en áreas con alta exposición a la intemperie. 

###  Medición y forma de pago 

Para medir y pagar la actividad de construcción de muro de ladrillo gambote o adobito con un espesor de 12 centímetros, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de muro construido en todos los predios durante la ejecución del proyecto. Esto incluirá todas las secciones de muro erigidas con ladrillos, independientemente de su forma o dimensiones específicas. La medición considerará la cantidad de metros cuadrados de muro de ladrillo construido, teniendo en cuenta la complejidad del diseño y las características del terreno donde se encuentre. Se incluirán tanto las secciones rectas como las curvas del muro. El pago se efectuará según la cantidad de metros cuadrados de muro de ladrillo construido, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A., asegurando que se cumplan los estándares de calidad y las especificaciones técnicas definidas en el proyecto. 
