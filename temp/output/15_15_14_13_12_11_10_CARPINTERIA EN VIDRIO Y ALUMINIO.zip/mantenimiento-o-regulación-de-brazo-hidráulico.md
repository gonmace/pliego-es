##  Mantenimiento o Regulación de Brazo Hidráulico 

###  Definición 

El mantenimiento o regulado de brazo hidráulico consiste en la inspección, ajuste, lubricación y, de ser necesario, reparación de brazos hidráulicos utilizados en sistemas de apertura y cierre de puertas automáticas. El objetivo es garantizar su correcto funcionamiento, prolongar su vida útil y prevenir posibles fallos operativos. Esta actividad es esencial para mantener la seguridad y eficiencia de los sistemas de acceso en edificaciones comerciales, industriales y residenciales. 

###  Materiales, Equipos y Herramientas 

  * Lubricantes y grasas especiales para sistemas hidráulicos. 
  * Juntas y sellos de goma de repuesto. 
  * Tornillos, pernos y tuercas. 
  * Aceite hidráulico según las especificaciones del fabricante. 
  * Productos anti-corrosión. 
  * Herramientas manuales (llaves, destornilladores, alicates). 
  * Equipos de medición (manómetros, termómetros). 
  * Equipos de elevación y soporte (gatos hidráulicos, caballetes). 
  * Equipos de limpieza (aspiradoras, paños de limpieza). 
  * Equipos de protección personal (EPP): guantes, gafas de seguridad, casco, calzado de seguridad. 
  * Técnicos especializados en mantenimiento de sistemas hidráulicos. 
  * Ayudantes de mantenimiento. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento inicia con una inspección visual y operativa de los brazos hidráulicos para identificar posibles fugas de aceite, desgaste de juntas, componentes dañados o cualquier otro problema. Se procederá a limpiar la superficie de los brazos y de los componentes internos, eliminando suciedad y residuos que puedan afectar su funcionamiento. 

Luego, se verificará el nivel de aceite hidráulico y se procederá a rellenar o cambiar el aceite si es necesario, asegurando que se encuentre dentro de los límites recomendados por el fabricante. Se ajustarán y lubricarán todas las piezas móviles, incluyendo bisagras, pistones y conexiones, utilizando los lubricantes adecuados para cada tipo de componente. 

Si se detectan fugas de aceite o desgaste significativo de juntas, se procederá a su reemplazo utilizando repuestos de calidad aprobada por el fabricante del brazo hidráulico. Se realizarán pruebas operativas para verificar el correcto funcionamiento del sistema y se realizarán ajustes finos según sea necesario para garantizar un rendimiento óptimo. 

El contratista es responsable de garantizar que se cumplan todas las normas de seguridad, supervisión y regulaciones aplicables durante el desarrollo de la actividad. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de mantenimiento o regulado de brazo hidráulico, la unidad de medida será la pieza (unidad). Se contabilizará cada brazo hidráulico que haya recibido el mantenimiento completo conforme a las especificaciones del proyecto. 

La medición considerará el número total de brazos hidráulicos mantenidos y regulados, asegurando que cada uno cumpla con los criterios de funcionamiento y seguridad establecidos. El pago se efectuará según la cantidad de piezas mantenidas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
