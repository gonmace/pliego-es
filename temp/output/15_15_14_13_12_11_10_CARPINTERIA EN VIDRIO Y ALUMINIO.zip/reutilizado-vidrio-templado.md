##  Reutilizado Vidrio Templado 

###  Definición 

El proyecto de reutilizado de vidrio templado consiste en la recuperación y reutilización de paneles de vidrio templado provenientes de demolición o desmantelamiento de estructuras, con el objetivo de darles un nuevo propósito en la construcción. Esto implica la recolección, clasificación, limpieza, corte y preparación del vidrio para su posterior uso en la fabricación de nuevos elementos arquitectónicos. 

###  Materiales, Equipos y Herramientas 

  * Paneles de vidrio templado recuperados. 
  * Herramientas de corte y pulido de vidrio. 
  * Adhesivos y selladores adecuados para vidrio. 
  * Materiales de embalaje y protección. 
  * Máquinas cortadoras de vidrio. 
  * Equipos de limpieza y lavado de vidrio. 
  * Herramientas manuales para manipulación de vidrio. 
  * Equipos de protección personal (EPP) 
  * Personal especializado en el manejo y corte de vidrio. 
  * Operarios para el transporte y manipulación de los paneles de vidrio. 
  * Personal de apoyo para labores logísticas y de limpieza. 



###  Procedimiento 

El proceso comienza con la recolección de los paneles de vidrio templado, los cuales son transportados al área de trabajo. Se realiza una inspección visual para descartar aquellos paneles que presenten daños estructurales significativos que impidan su reutilización. 

Posteriormente, se procede a la limpieza de los paneles de vidrio para eliminar cualquier residuo o suciedad adherida. Luego, se lleva a cabo el corte de los paneles según las dimensiones requeridas para su nuevo uso, utilizando máquinas cortadoras de vidrio bajo las medidas de seguridad correspondientes. 

Una vez cortados, los paneles son inspeccionados nuevamente para verificar que no presenten astillas ni imperfecciones. Se aplican adhesivos y selladores adecuados en los bordes cortados para garantizar la seguridad y durabilidad de los paneles. 

Finalmente, los paneles de vidrio reutilizados son embalados y almacenados de manera segura para su posterior utilización en proyectos de construcción. 

El contratista es responsable de supervisar que se cumplan todas las normas de seguridad y que el trabajo se realice de acuerdo con las especificaciones técnicas y regulaciones aplicables. EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición y pago de la actividad se realizará en metros cuadrados (m²), considerando el área total de los paneles de vidrio reutilizados. Se calculará la cantidad de metros cuadrados de vidrio reutilizado, de acuerdo con los términos y condiciones del contrato establecido con el contratista, basado en la aprobación por parte de EMBOL S.A. 
