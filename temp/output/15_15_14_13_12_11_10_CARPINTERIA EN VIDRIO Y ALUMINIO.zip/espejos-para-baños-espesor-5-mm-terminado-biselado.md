##  Espejos para Baños Espesor 5 mm Terminado Biselado 

###  Definición 

El proyecto consiste en la instalación de espejos para baños con un espesor de 5 mm y acabado biselado. Estos espejos se colocarán en los baños de la edificación, proporcionando una superficie reflectante de alta calidad y estética para los usuarios. 

###  Materiales, Equipos y Herramientas 

  * Espejos de 5 mm de espesor con acabado biselado. 
  * Adhesivo especial para espejos. 
  * Tornillería de fijación (si es necesario). 
  * Sellador para juntas y bordes. 
  * Nivel de burbuja. 
  * Cinta métrica. 
  * Taladro con brocas para concreto o cerámica (si es necesario). 
  * Destornilladores. 
  * Espátulas. 
  * Equipos de protección personal (EPP) 
  * Instaladores especializados en espejos. 
  * Ayudantes para la manipulación y colocación de los espejos. 



###  Procedimiento 

Se inicia con la preparación del área donde se instalarán los espejos. Se verifica que la superficie esté limpia, seca y nivelada. Se toman las medidas necesarias para determinar la ubicación y dimensiones de los espejos, asegurando un ajuste preciso. 

A continuación, se aplica el adhesivo especial en la parte posterior del espejo, asegurando una cobertura uniforme. Se coloca el espejo en la posición previamente marcada y se presiona firmemente contra la superficie para garantizar una adhesión adecuada. 

Si es necesario, se utilizan tornillos y tacos para fijar los espejos a la pared de manera segura. Se sellan las juntas y bordes con sellador para evitar la filtración de agua y humedad, especialmente en baños con duchas o lavamanos. 

El contratista es responsable de supervisar que se cumplan todas las normas de seguridad y que el trabajo se realice de acuerdo con las especificaciones técnicas y regulaciones aplicables. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición y pago de la actividad se realizará en metros cuadrados (m²), considerando el área total cubierta por los espejos instalados en los baños de la edificación. Se calculará la superficie total de los espejos colocados, independientemente de su forma o dimensiones específicas. El pago se efectuará de acuerdo con los términos y condiciones del contrato establecido con el contratista, basado en la cantidad de metros cuadrados de espejos instalados y la aprobación por parte de EMBOL S.A. 
