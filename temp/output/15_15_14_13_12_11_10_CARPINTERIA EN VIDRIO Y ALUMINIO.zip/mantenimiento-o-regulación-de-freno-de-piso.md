##  Mantenimiento o Regulación de Freno de Piso 

###  Definición 

El mantenimiento o regulado del freno de piso consiste en la inspección, ajuste, lubricación y, de ser necesario, reparación de los frenos instalados en el piso de edificaciones comerciales, industriales o residenciales. El objetivo es garantizar su correcto funcionamiento, seguridad y durabilidad, así como prevenir posibles fallas operativas que puedan comprometer la seguridad de las personas y el correcto funcionamiento de los sistemas de acceso y seguridad. 

###  Materiales, Equipos y Herramientas 

  * Lubricantes y grasas especiales para sistemas de frenos. 
  * Juntas y sellos de goma de repuesto. 
  * Tornillos, pernos y tuercas. 
  * Componentes de frenos de repuesto según las especificaciones del fabricante. 
  * Herramientas manuales (llaves, destornilladores, alicates). 
  * Equipos de medición (calibradores, medidores de desgaste). 
  * Equipos de elevación y soporte (gatos hidráulicos, caballetes). 
  * Equipos de limpieza (aspiradoras, paños de limpieza). 
  * Equipos de protección personal (EPP) 
  * Técnicos especializados en mantenimiento de sistemas de frenos. 
  * Ayudantes de mantenimiento. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento inicia con una inspección visual y operativa de los frenos de piso para identificar desgaste excesivo, daños, holguras u otros problemas que puedan afectar su funcionamiento. Se procederá a limpiar la superficie de los frenos y de los componentes internos, eliminando suciedad, grasa y residuos que puedan afectar su rendimiento. 

Luego, se verificará el desgaste de las pastillas de freno y, de ser necesario, se procederá a su reemplazo utilizando repuestos de calidad aprobada por el fabricante del sistema de frenos. Se ajustarán y lubricarán todas las piezas móviles, incluyendo resortes, pivotes y conexiones, utilizando los lubricantes adecuados para cada tipo de componente. 

Si se detectan daños en componentes críticos del sistema de frenos, se procederá a su reparación o reemplazo, siguiendo las especificaciones y recomendaciones del fabricante. Se realizarán pruebas operativas para verificar el correcto funcionamiento del sistema y se realizarán ajustes finos según sea necesario para garantizar un rendimiento óptimo. 

El contratista es responsable de garantizar que se cumplan todas las normas de seguridad, supervisión y regulaciones aplicables durante el desarrollo de la actividad. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de mantenimiento o regulado del freno de piso, la unidad de medida será la pieza (unidad). Se contabilizará cada freno de piso que haya recibido el mantenimiento completo conforme a las especificaciones del proyecto. 

La medición considerará el número total de frenos de piso mantenidos y regulados, asegurando que cada uno cumpla con los criterios de funcionamiento y seguridad establecidos. El pago se efectuará según la cantidad de piezas mantenidas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
