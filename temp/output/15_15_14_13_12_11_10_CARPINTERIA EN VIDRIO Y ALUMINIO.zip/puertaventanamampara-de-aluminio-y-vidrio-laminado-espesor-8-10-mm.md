##  Puerta/Ventana/Mampara de Aluminio y Vidrio Laminado Espesor 8-10 mm 

###  Definición 

La actividad consiste en la fabricación, suministro e instalación de puertas, ventanas y mamparas de aluminio y vidrio laminado con un espesor de 8-10 mm. Estos elementos deben cumplir con los más altos estándares de calidad y seguridad, ofreciendo durabilidad y resistencia. El diseño incluirá perfiles de aluminio de alta resistencia y vidrio laminado, que proporcionen una estética moderna y funcionalidad. La instalación deberá garantizar el correcto funcionamiento y sellado de los elementos, asegurando una adecuada aislación térmica y acústica. 

###  Materiales, Equipos y Herramientas 

  * Vidrio laminado de 8-10 mm 
  * Perfiles de aluminio de alta resistencia 
  * Selladores de silicona neutra 
  * Herrajes y accesorios (bisagras, manillas, cerraduras) 
  * Burletes y juntas de goma 
  * Tornillos y fijaciones 
  * Taladros y destornilladores eléctricos 
  * Sierras de corte para aluminio y vidrio 
  * Ventosas para manipulación de vidrio 
  * Escaleras y andamios (certificados) 
  * Equipos de protección personal (EPP): cascos, guantes, gafas de seguridad, botas con punta de acero, mascarillas respiratorias, chalecos reflectantes 
  * Ingenieros civiles 
  * Arquitectos 
  * Supervisores de seguridad 
  * Instaladores especializados en aluminio y vidrio 
  * Personal de apoyo logístico 



###  Procedimiento 

El procedimiento para la instalación de puertas, ventanas y mamparas de aluminio y vidrio laminado comenzará con la preparación del área de trabajo. Se delimitará y señalizará el espacio para garantizar la seguridad del personal y evitar el acceso no autorizado. Si es necesario, se utilizarán andamios y escaleras certificadas para acceder a las áreas elevadas. 

Primero, se realizará una inspección del área para asegurar que las superficies estén niveladas y adecuadas para la instalación. Los perfiles de aluminio se cortarán a medida según las especificaciones del diseño y se fijarán a las estructuras existentes utilizando tornillos y anclajes adecuados. Se emplearán niveles láser para garantizar una alineación precisa de los perfiles. 

Una vez instalada la estructura de soporte, se procederá a la colocación de las hojas de vidrio laminado. Las hojas de vidrio se manipularán utilizando ventosas y se insertarán cuidadosamente en los perfiles de aluminio, asegurando un ajuste perfecto. Se aplicarán selladores de silicona neutra en todas las juntas para garantizar la hermeticidad y evitar filtraciones. 

Los herrajes y accesorios, como bisagras, manillas y cerraduras, se instalarán conforme a las especificaciones técnicas, asegurando que todas las partes móviles funcionen correctamente. Se colocarán burletes y juntas de goma para mejorar la aislación térmica y acústica. 

Durante todo el proceso, se realizarán inspecciones periódicas para verificar la calidad del trabajo y asegurar que se cumplan los estándares especificados. Se implementarán medidas de control de calidad y se seguirán todas las normas de seguridad aplicables. 

EMBOL se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de puertas, ventanas y mamparas de aluminio y vidrio laminado, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por los elementos instalados durante la ejecución del proyecto. Esto incluirá todas las áreas cubiertas con precisión, abarcando la totalidad del espacio destinado para este propósito, independientemente de su forma o dimensiones específicas. 

La medición considerará la cantidad de metros cuadrados cubiertos por las puertas, ventanas y mamparas, incluyendo la instalación de perfiles, vidrio, herrajes y selladores. El pago se efectuará según la cantidad de metros cuadrados de trabajo realizado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
