##  Frenos Hidráulicos de Alto Tráfico 

###  Definición 

La actividad comprende la provisión e instalación de frenos hidráulicos de alto tráfico marca DORMA en puertas de acceso y salida de edificios e instalaciones con uso intensivo. Estos frenos hidráulicos proporcionan un cierre controlado y uniforme de las puertas, aumentando la seguridad y la durabilidad de estas, especialmente en áreas con un alto volumen de tráfico. La instalación debe cumplir con las especificaciones técnicas proporcionadas por el fabricante y con todas las normativas vigentes en materia de construcción y seguridad. 

###  Materiales, Equipos y Herramientas 

  * Frenos hidráulicos de alto tráfico certificados marca DORMA, adecuados para diferentes pesos y tamaños de puertas. 
  * Tornillos y anclajes de alta resistencia, específicos para la instalación en diferentes tipos de marcos (madera, metal, vidrio). 
  * Placas de montaje y otros accesorios necesarios para la correcta fijación de los frenos hidráulicos. 
  * Taladros eléctricos con brocas adecuadas para los diferentes materiales de los marcos de las puertas. 
  * Llaves de ajuste y destornilladores (manuales y eléctricos). 
  * Niveles de burbuja y láser para asegurar la correcta alineación. 
  * Martillos y punzones. 
  * Equipos de protección personal (EPP) 
  * Técnicos especialistas en la instalación de dispositivos hidráulicos. 
  * Ayudantes de instalación. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento de instalación de los frenos hidráulicos de alto tráfico comienza con una inspección detallada de las puertas y los marcos para asegurar que están en buen estado y son adecuados para la instalación de los frenos hidráulicos. Los puntos de fijación se marcan con precisión utilizando niveles de burbuja y láser para garantizar una alineación correcta. 

Se perforan los orificios necesarios en la puerta y el marco utilizando taladros eléctricos, asegurando que el tamaño y la profundidad sean adecuados para los tornillos y anclajes. Los frenos hidráulicos y las placas de montaje se posicionan y fijan utilizando los tornillos y anclajes de alta resistencia, asegurando una sujeción firme y segura. 

Una vez instalados, los frenos hidráulicos se ajustan según las especificaciones del fabricante, configurando la velocidad de cierre y el ángulo de apertura para cumplir con los requerimientos de tráfico intenso. Se realizan pruebas de funcionamiento para verificar que el freno hidráulico opera de manera suave y eficiente, realizando los ajustes necesarios para garantizar un cierre controlado y sin obstrucciones. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y cumpla con todas las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar todo el proceso para garantizar que se cumplan los estándares de calidad especificados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de provisión e instalación de frenos hidráulicos de alto tráfico, la unidad de medida será la pieza (unidad). Se contabilizará cada freno hidráulico instalado conforme a las especificaciones del proyecto. 

La medición considerará el número total de frenos hidráulicos instalados, asegurando que cada uno cumpla con los criterios de funcionamiento y calidad establecidos. El pago se efectuará según la cantidad de piezas instaladas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
