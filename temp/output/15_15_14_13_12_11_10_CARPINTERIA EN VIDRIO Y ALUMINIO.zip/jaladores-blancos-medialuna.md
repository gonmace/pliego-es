##  Jaladores Blancos Medialuna 

###  Definición 

La actividad consiste en la provisión e instalación de jaladores blancos en forma de medialuna en puertas de acceso. Estos jaladores serán instalados en diversas áreas de alto tráfico dentro de las instalaciones, garantizando funcionalidad y estética. Los jaladores deben ser fabricados en materiales duraderos y resistentes a la corrosión, con un acabado blanco que combine con la decoración y diseño del entorno. 

###  Materiales, Equipos y Herramientas 

  * Jaladores blancos en forma de medialuna, fabricados en aluminio o acero inoxidable con recubrimiento blanco. 
  * Tornillos y pernos de fijación adecuados para los distintos tipos de puertas (madera, vidrio, metal). 
  * Placas de soporte y embellecedores, si son necesarios. 
  * Taladros eléctricos con brocas específicas para diferentes materiales de puerta. 
  * Llaves de ajuste y destornilladores (manuales y eléctricos). 
  * Niveles de burbuja y láser para asegurar la correcta alineación. 
  * Martillos y punzones. 
  * Equipos de protección personal (EPP) 
  * Técnicos especialistas en instalación de hardware para puertas. 
  * Ayudantes de instalación. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento de instalación de los jaladores blancos en forma de medialuna inicia con la inspección detallada de las puertas y su estructura para asegurar que son adecuadas para la instalación. Se marcan los puntos de fijación con precisión utilizando niveles de burbuja y láser para garantizar una correcta alineación y altura conforme a las normativas de accesibilidad. 

Se perforan los orificios necesarios en las puertas utilizando taladros eléctricos con brocas adecuadas al material de la puerta. Los jaladores y sus componentes de fijación se posicionan y aseguran mediante tornillos y pernos, asegurando una sujeción firme y segura. Se debe prestar especial atención a la alineación y nivelación de los jaladores para garantizar una instalación funcional y estética. 

Una vez instalados, se verificará el correcto funcionamiento y fijación de los jaladores mediante pruebas de resistencia y uso. El supervisor de calidad revisará cada instalación para asegurarse de que cumple con los estándares especificados y que todos los componentes están correctamente instalados. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y cumpla con todas las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar todo el proceso para garantizar que se cumplan los estándares de calidad especificados. EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de provisión e instalación de jaladores blancos en forma de medialuna, la unidad de medida será la pieza (unidad). Se contabilizará cada jalador instalado conforme a las especificaciones del proyecto. 

La medición considerará el número total de jaladores instalados, asegurando que cada uno cumpla con los criterios de funcionalidad y calidad establecidos. El pago se efectuará según la cantidad de piezas instaladas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
