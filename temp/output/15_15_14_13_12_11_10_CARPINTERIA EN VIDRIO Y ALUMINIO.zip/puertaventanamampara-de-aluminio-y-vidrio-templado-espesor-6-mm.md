##  Puerta/Ventana/Mampara de Aluminio y Vidrio Templado Espesor 6 mm 

###  Definición 

La actividad consiste en el diseño, provisión e instalación de puertas, ventanas y mamparas de aluminio con vidrio laminado. Esta tarea incluye todas las etapas desde la medición del sitio, selección de materiales, provisión, hasta la instalación final. Los elementos de aluminio y vidrio laminado proporcionan durabilidad, estética y seguridad, siendo ideales para aplicaciones en edificaciones residenciales, comerciales e industriales. 

###  Materiales, Equipos y Herramientas 

  * Perfiles de aluminio (aleación 6063 T5 o equivalente) con recubrimiento anodizado o pintado. 
  * Vidrio laminado de seguridad de 6 mm (3 mm + 3 mm con intercalario de PVB). 
  * Accesorios y herrajes: bisagras, cerraduras, manillas, juntas de goma, tornillería inoxidable. 
  * Herramientas de corte y mecanizado para aluminio: sierras de corte, fresadoras. 
  * Herramientas de corte y pulido de vidrio: cortavidrios, lijadoras. 
  * Equipos de sujeción y ensamblaje: taladros, destornilladores eléctricos, remachadoras. 
  * Equipos de medición: cintas métricas, niveles láser. 
  * Equipos de protección personal (EPP) 
  * Equipos para trabajos en altura (si se requiere): andamios certificados, arneses, líneas de vida, escaleras. 
  * Ingenieros civiles y/o arquitectos para supervisión y diseño. 
  * Técnicos especializados en carpintería de aluminio y vidrio. 
  * Asistentes y operarios para tareas de apoyo y logística. 



###  Procedimiento 

El procedimiento comienza con la evaluación y medición del sitio donde se instalarán los elementos de aluminio y vidrio laminado. Los ingenieros y arquitectos supervisan esta etapa para asegurar que las dimensiones y especificaciones cumplen con los requisitos del proyecto. 

Una vez obtenidas las medidas, se procede con la fabricación de los marcos y paneles en el taller. Los perfiles de aluminio se cortan y ensamblan de acuerdo con el diseño aprobado. El vidrio laminado se corta a medida y se revisa para detectar cualquier defecto. Se instalan los herrajes y juntas, garantizando que todos los componentes se ajusten perfectamente. 

En la etapa de instalación, se transportan los componentes al sitio de construcción. Se prepara el área de instalación, asegurando que las superficies estén limpias y niveladas. Se colocan los marcos de aluminio y se fijan adecuadamente al soporte estructural mediante anclajes y tornillería. 

Se instalan los paneles de vidrio laminado en los marcos, utilizando selladores y juntas para asegurar un ajuste hermético y seguro. Se ajustan los herrajes y se realizan pruebas funcionales para verificar que puertas, ventanas y mamparas operan correctamente. 

El contratista es responsable de hacer cumplir todas las normas de seguridad durante cada fase del proyecto, así como la supervisión constante del personal para asegurar el cumplimiento de los estándares de calidad. Además, se deben seguir todas las normativas vigentes relativas a la fabricación e instalación de elementos de aluminio y vidrio. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de puertas, ventanas y mamparas de aluminio y vidrio laminado, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por los elementos instalados, considerando las dimensiones precisas de cada componente. El pago se efectuará según la cantidad de metros cuadrados instalados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 

Esta medición incluirá todos los elementos instalados dentro del alcance del proyecto, independientemente de su forma o tamaño específico. La medición considerará la superficie total cubierta por los componentes instalados, y el pago se ajustará en función del área efectiva instalada y verificada por el supervisor de proyecto de EMBOL S.A. 
