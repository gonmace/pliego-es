##  Felpas para Ventanas y Puertas 

###  Definición 

El proyecto consiste en el cambio de felpas en ventanas y puertas para garantizar un correcto sellado y aislamiento térmico y acústico en las edificaciones. Este trabajo incluye la remoción de las felpas antiguas, la preparación de las superficies, la instalación de las nuevas felpas y la verificación del correcto funcionamiento de las ventanas y puertas. 

###  Materiales, Equipos y Herramientas 

  * Felpas adecuadas al tipo de ventana o puerta. 
  * Adhesivo o sellador compatible con el material de las felpas y las superficies a sellar. 
  * Destornilladores. 
  * Espátulas. 
  * Cuchillas o cutter. 
  * Equipos de protección personal (EPP) 
  * Instaladores especializados en carpintería. 
  * Ayudantes para la manipulación de materiales y apoyo logístico. 



###  Procedimiento 

El procedimiento comienza con la evaluación de las ventanas y puertas para determinar el estado de las felpas existentes y las necesidades de reemplazo. Se procede a retirar las felpas antiguas con cuidado para no dañar las superficies adyacentes. 

Luego, se limpian y preparan las superficies donde se instalarán las nuevas felpas, asegurando que estén libres de polvo, suciedad y residuos de adhesivo. Se cortan las felpas nuevas a la medida adecuada y se aplican en las ranuras correspondientes, asegurando un ajuste firme y uniforme. 

Después de instalar las felpas, se verifica el correcto cierre y sellado de las ventanas y puertas, realizando ajustes si es necesario para garantizar un funcionamiento óptimo. Se comprueba que no existan filtraciones de aire o agua y que el aislamiento térmico y acústico sea efectivo. 

El contratista es responsable de supervisar que se cumplan todas las normas de seguridad y que el trabajo se realice de acuerdo con las especificaciones técnicas y regulaciones aplicables. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición y pago de la actividad se realizará en metros lineales (m lineal), considerando la longitud total de las felpas instaladas en ventanas y puertas. Se calculará la cantidad de metros lineales de felpa instalada, de acuerdo con los términos y condiciones del contrato establecido con el contratista, basado en la aprobación por parte de EMBOL S.A. 
