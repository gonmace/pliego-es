##  Brazos Hidráulicos de Alto Tráfico Capacidad 80 a 120 kg 

###  Definición 

La actividad consiste en la provisión y colocación de brazos hidráulicos de alto tráfico en puertas de acceso y salida en instalaciones con uso intensivo. Estos dispositivos tienen como objetivo mejorar la durabilidad y funcionalidad de las puertas, asegurando un cierre controlado y suave para prevenir daños y garantizar la seguridad de los usuarios. La instalación debe cumplir con todas las especificaciones técnicas y normativas vigentes, asegurando la máxima eficiencia y seguridad en su operación. Los brazos hidráulicos deberán ser marca DORMA o LINCE, con capacidad de soportar entre 80 y 120 kg. 

###  Materiales, Equipos y Herramientas 

  * Brazos hidráulicos de alto tráfico certificados (marca DORMA o LINCE, 80-1200 kg) 
  * Tornillos y anclajes de alta resistencia adecuados para la instalación en diferentes tipos de materiales (madera, metal, vidrio) 
  * Placas de montaje y accesorios necesarios para la fijación del brazo hidráulico 
  * Taladros eléctricos con brocas apropiadas para diferentes materiales 
  * Llaves de ajuste y destornilladores (manuales y eléctricos) 
  * Martillos y punzones 
  * Equipos de protección personal (EPP): guantes de trabajo, gafas de seguridad, casco, calzado de seguridad 
  * Escaleras y andamios certificados (si se requiere trabajar en altura) 
  * Técnicos especialistas en instalación de herrajes y brazos hidráulicos 
  * Ayudantes de instalación 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento comienza con una inspección detallada de las puertas y los marcos donde se instalarán los brazos hidráulicos, asegurando que las superficies estén en buen estado y sean adecuadas para la instalación. Se mide y marca con precisión los puntos de fijación, utilizando niveles de burbuja y láser para asegurar la correcta alineación horizontal y vertical. 

A continuación, se perforan los orificios necesarios en la puerta y el marco con taladros eléctricos, asegurando que el tamaño y la profundidad sean adecuados para los tornillos y anclajes. Los brazos hidráulicos (marca DORMA o LINCE) y las placas de montaje se posicionan y fijan utilizando tornillos y anclajes de alta resistencia, asegurando una sujeción firme y segura. 

Una vez instalados, los brazos hidráulicos se ajustan según las especificaciones del fabricante, configurando la velocidad de cierre y el ángulo de apertura para cumplir con los requerimientos de tráfico intenso. Se realizan pruebas de funcionamiento para verificar que el brazo hidráulico opera de manera suave y eficiente, realizando los ajustes necesarios para garantizar un cierre controlado y sin obstrucciones. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y cumpla con todas las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar todo el proceso para garantizar que se cumplan los estándares de calidad especificados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de provisión y colocación de brazos hidráulicos de alto tráfico, la unidad de medida será la pieza (unidad). Se contabilizará cada brazo hidráulico instalado conforme a las especificaciones del proyecto. 

La medición considerará el número total de brazos hidráulicos instalados, asegurando que cada uno cumpla con los criterios de funcionamiento y calidad establecidos. El pago se efectuará según la cantidad de piezas instaladas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
