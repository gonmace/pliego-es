##  Mamparas Fijas de Vidrio Templado Espesor 10 mm 

###  Definición 

La actividad consiste en la instalación de mamparas fijas de vidrio templado con un grosor de 10 mm. Estas mamparas se utilizan para dividir espacios interiores de manera elegante y funcional, proporcionando separación visual sin obstaculizar la entrada de luz natural. Son comunes en áreas de oficinas, locales comerciales y residencias. 

###  Materiales, Equipos y Herramientas 

  * Vidrio templado con un grosor de 10 mm. 
  * Perfiles de aluminio o acero para el marco de la mampara. 
  * Selladores y adhesivos especiales para la fijación del vidrio. 
  * Herramientas manuales y eléctricas para el corte y manipulación del vidrio y los perfiles metálicos. 
  * Equipos de elevación y transporte para manipular el vidrio con seguridad. 
  * Ingenieros civiles y/o arquitectos para la supervisión y planificación. 
  * Personal técnico especializado en la instalación de mamparas de vidrio templado. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal (EPP). 



###  Procedimiento 

Se inicia con la toma de medidas precisas del área donde se instalará la mampara, asegurando un ajuste perfecto y una distribución equitativa de los paneles de vidrio. 

Posteriormente, se procede con el corte y pulido del vidrio templado según las dimensiones especificadas, utilizando herramientas y técnicas adecuadas para garantizar bordes lisos y seguros. 

Una vez preparados los paneles de vidrio, se procede con la instalación de los perfiles metálicos, asegurando su nivelación y alineación. Los paneles de vidrio se fijan a los perfiles utilizando selladores y adhesivos especiales, garantizando una unión sólida y duradera. 

Finalmente, se realizan ajustes finos para asegurar que la mampara esté correctamente instalada y funcione correctamente. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la instalación de mamparas de vidrio templado. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de las mamparas fijas de vidrio templado, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por las mamparas instaladas, considerando todas las superficies de vidrio utilizadas en el proyecto. El pago se efectuará según la cantidad de metros cuadrados de vidrio tratados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL. 
