##  Mantenimiento de Puertas Abatibles, Corredizas, Rieles y Rodamientos 

###  Definición 

La actividad de mantenimiento de puertas abatibles, corredizas, rieles y rodamientos incluye la inspección, limpieza, lubricación, ajuste y, si es necesario, la sustitución de componentes defectuosos. El objetivo es asegurar el correcto funcionamiento y la seguridad de las puertas, así como prolongar su vida útil. Este mantenimiento es esencial para prevenir fallos operativos y garantizar un uso seguro y eficiente de las puertas en todas las instalaciones. 

###  Materiales, Equipos y Herramientas 

  * Lubricantes adecuados para rieles y rodamientos. 
  * Paños de limpieza y desengrasantes. 
  * Tornillos, pernos y tacos de fijación de repuesto. 
  * Rodamientos y componentes de rieles de repuesto según especificaciones del fabricante. 
  * Selladores y productos anti-corrosión. 
  * Herramientas manuales (llaves, destornilladores, alicates). 
  * Herramientas eléctricas (taladros, amoladoras). 
  * Equipos de medición y alineación (niveles de burbuja y láser). 
  * Elevadores y gatos hidráulicos para el ajuste de puertas pesadas. 
  * Equipos de protección personal (EPP) 
  * Técnicos especializados en mantenimiento de puertas. 
  * Ayudantes de mantenimiento. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento comienza con una inspección visual y operativa de las puertas para identificar cualquier desgaste, mal funcionamiento o daño en los componentes. Se procederá a limpiar los rieles y rodamientos, eliminando cualquier residuo que pueda obstruir el movimiento. A continuación, se aplicará lubricante adecuado a los rieles y rodamientos para asegurar un deslizamiento suave y sin fricción. 

Se revisarán y ajustarán todos los tornillos y pernos, asegurando que las puertas estén correctamente alineadas y fijas. Si se detectan componentes dañados o desgastados, se procederá a su sustitución inmediata con repuestos de calidad aprobada. En el caso de puertas corredizas, se verificará el estado de los rieles, realizando ajustes o sustituciones según sea necesario. 

El contratista es responsable de asegurar que todo el personal use los equipos de protección personal adecuados y siga todas las normativas de seguridad vigentes. Durante todo el proceso, se mantendrá un registro detallado de las actividades realizadas, incluyendo cualquier observación relevante sobre el estado de las puertas y las acciones correctivas tomadas. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de mantenimiento de puertas abatibles, corredizas, rieles y rodamientos, la unidad de medida será la pieza (unidad). Se contabilizará cada puerta que haya recibido el mantenimiento completo conforme a las especificaciones del proyecto. 

La medición considerará el número total de puertas mantenidas, asegurando que cada una cumpla con los criterios de funcionamiento y seguridad establecidos. El pago se efectuará según la cantidad de piezas mantenidas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 

. 
