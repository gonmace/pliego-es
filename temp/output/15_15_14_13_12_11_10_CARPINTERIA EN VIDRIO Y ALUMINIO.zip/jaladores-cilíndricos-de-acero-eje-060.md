##  Jaladores Cilíndricos de Acero Eje 0.60 

###  Definición 

La actividad consiste en la provisión e instalación de jaladores cilíndricos de acero con un eje de 0.60 metros en puertas de acceso. Estos jaladores serán instalados en diversas áreas dentro de las instalaciones, garantizando su funcionalidad, durabilidad y cumplimiento con las normas estéticas y de diseño del entorno. Los jaladores deben ser fabricados en acero inoxidable, ofreciendo resistencia a la corrosión y un acabado de alta calidad. 

###  Materiales, Equipos y Herramientas 

  * Jaladores cilíndricos de acero inoxidable, eje de 0.60 metros. 
  * Tornillos, pernos y tacos de fijación adecuados para diferentes tipos de puertas (madera, vidrio, metal). 
  * Placas de soporte y embellecedores, según sea necesario. 
  * Taladros eléctricos con brocas adecuadas para los diferentes materiales de las puertas. 
  * Llaves de ajuste, destornilladores (manuales y eléctricos). 
  * Niveles de burbuja y láser para asegurar la correcta alineación. 
  * Martillos y punzones. 
  * Equipos de protección personal (EPP) 
  * Técnicos especializados en instalación de hardware para puertas. 
  * Ayudantes de instalación. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento de instalación de los jaladores cilíndricos de acero inicia con una inspección detallada de las puertas para asegurar que son adecuadas para la instalación. Se marcan los puntos de fijación con precisión utilizando niveles de burbuja y láser para garantizar una correcta alineación y altura conforme a las normativas de accesibilidad. 

Se perforan los orificios necesarios en las puertas utilizando taladros eléctricos con brocas específicas al material de la puerta. Los jaladores y sus componentes de fijación se posicionan y aseguran mediante tornillos, pernos y tacos, garantizando una sujeción firme y segura. Es crucial prestar atención a la alineación y nivelación de los jaladores para asegurar una instalación funcional y estética. 

Una vez instalados, se verifica el correcto funcionamiento y fijación de los jaladores mediante pruebas de resistencia y uso. El supervisor de calidad revisará cada instalación para asegurarse de que cumple con los estándares especificados y que todos los componentes están correctamente instalados. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y cumpla con todas las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar todo el proceso para garantizar que se cumplan los estándares de calidad especificados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de provisión e instalación de jaladores cilíndricos de acero, la unidad de medida será la pieza (unidad). Se contabilizará cada jalador instalado conforme a las especificaciones del proyecto. 

La medición considerará el número total de jaladores instalados, asegurando que cada uno cumpla con los criterios de funcionalidad y calidad establecidos. El pago se efectuará según la cantidad de piezas instaladas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
