##  Ventana Tipo Celosía para Baño Dimensiones 60 x 60 cm 

###  Definición 

La actividad consiste en la fabricación e instalación de una ventana tipo celosía para baño, con dimensiones de 60 x 60 cm. Esta ventana se instalará en el espacio designado para ventilación y entrada de luz natural en baños residenciales o comerciales. 

###  Materiales, Equipos y Herramientas 

  * Perfiles de aluminio o PVC para la estructura de la ventana. 
  * Láminas de vidrio templado o acrílico de 4 mm de espesor. 
  * Bisagras y herrajes para la operación de la celosía. 
  * Selladores y adhesivos para la fijación de los elementos. 
  * Herramientas manuales y eléctricas para corte, perforación y ensamblaje. 
  * Equipo de medición para garantizar la precisión en las dimensiones. 
  * Equipo de elevación y transporte para la manipulación de materiales y herramientas. 
  * Ingenieros civiles y/o arquitectos para la planificación y diseño. 
  * Personal técnico especializado en la fabricación e instalación de ventanas. 
  * Asistentes para apoyo logístico y operativo. 
  * Equipo de protección personal (EPP). 



###  Procedimiento 

Se inicia con la toma de medidas precisas del espacio donde se instalará la ventana, garantizando un ajuste perfecto. Luego, se procede con el corte de los perfiles de aluminio o PVC según las dimensiones especificadas. 

Posteriormente, se ensamblan los perfiles para formar la estructura de la ventana, asegurando una correcta alineación y fijación de las piezas. Se instalan las láminas de vidrio templado o acrílico en la estructura, utilizando selladores y adhesivos para garantizar una unión segura y hermética. 

Una vez ensamblada la ventana, se procede con la instalación en el hueco preparado en la pared del baño. Se fijan las bisagras y herrajes necesarios para la operación de la celosía, asegurando un funcionamiento suave y eficiente. 

Finalmente, se realizan pruebas de funcionamiento para verificar que la ventana se abre y cierra correctamente, garantizando un adecuado flujo de aire y entrada de luz en el baño. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la fabricación e instalación de ventanas. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de fabricación e instalación de la ventana tipo celosía, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por la ventana instalada, considerando las dimensiones especificadas. El pago se efectuará según la cantidad de metros cuadrados de ventana instalada, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
