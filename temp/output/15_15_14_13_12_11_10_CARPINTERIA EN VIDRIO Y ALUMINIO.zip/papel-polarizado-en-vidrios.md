##  Papel Polarizado en Vidrios 

###  Definición 

La actividad consiste en el suministro y aplicación de papel polarizado en los vidrios existentes en una edificación. Este proceso incluye la preparación de la superficie del vidrio, la aplicación del papel polarizado y el acabado final para asegurar un resultado estético y funcional óptimo. El objetivo principal es reducir la entrada de luz solar directa, disminuir el deslumbramiento y mejorar la eficiencia energética del edificio. 

###  Materiales, Equipos y Herramientas 

  * Papel polarizado de alta calidad, con especificaciones de reducción de rayos UV y control de calor. 
  * Solución jabonosa para la aplicación del papel polarizado. 
  * Agua destilada para la limpieza de los vidrios. 
  * Cinta adhesiva para marcar áreas de trabajo. 
  * Rociadores para la aplicación de soluciones de limpieza y colocación. 
  * Espátulas de goma (squeegees) para alisar el papel polarizado. 
  * Cuchillas y cortadores de precisión para recortar el papel polarizado. 
  * Paños de microfibra para limpieza y secado. 
  * Escaleras y plataformas móviles (si es necesario para trabajos en altura). 
  * Equipos de protección personal (EPP): guantes de trabajo, gafas de seguridad, casco, calzado de seguridad. 
  * Andamios certificados, arneses, líneas de vida (si se requiere trabajar en altura) 
  * Técnicos especializados en la aplicación de películas de control solar. 
  * Ayudantes de instalación. 
  * Supervisor de calidad para garantizar el cumplimiento de las especificaciones técnicas. 



El procedimiento comienza con la evaluación del sitio para identificar todas las superficies de vidrio que recibirán el papel polarizado. Se realiza una inspección detallada para asegurar que los vidrios estén en buen estado y sean aptos para la aplicación de la película polarizada. 

Se procede con la limpieza exhaustiva de los vidrios utilizando una solución jabonosa y agua destilada para eliminar cualquier suciedad, grasa o residuos que puedan interferir con la adhesión del papel polarizado. Esta limpieza debe ser meticulosa para asegurar que no queden partículas atrapadas entre el vidrio y el papel polarizado. 

Con los vidrios limpios y secos, se marca el área de trabajo con cinta adhesiva para delimitar las zonas exactas de aplicación. El papel polarizado se corta previamente a las dimensiones necesarias, considerando un margen para el ajuste durante la instalación. 

La aplicación del papel polarizado se realiza rociando una solución jabonosa sobre el vidrio y la cara adhesiva del papel. Esto permite mover y ajustar el papel una vez colocado sobre el vidrio. Con la espátula de goma, se alisa el papel polarizado desde el centro hacia los bordes para eliminar burbujas de aire y exceso de solución, asegurando una adhesión uniforme y sin imperfecciones. 

Una vez instalado el papel polarizado, se realiza un corte de precisión en los bordes para un ajuste perfecto. Se deja secar completamente, verificando que no queden burbujas o arrugas. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y que se respeten las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar el proceso para garantizar que se cumplan los estándares de calidad especificados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de colocado de papel polarizado en vidrios, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de los vidrios cubiertos por el papel polarizado, considerando las dimensiones exactas de cada superficie tratada. 

La medición considerará la cantidad de metros cuadrados de vidrio cubiertos por el papel polarizado, teniendo en cuenta la precisión del corte y ajuste del papel. El pago se efectuará según la cantidad de metros cuadrados de papel polarizado aplicado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el área efectiva polarizada y la aprobación del supervisor de proyecto de EMBOL S.A. 
