##  Vidrio Laminado 

###  Definición 

La actividad implica la instalación o sustitución de paneles de vidrio sin ningún tipo de tratamiento adicional, como templado o laminado. Este tipo de vidrio se utiliza principalmente en aplicaciones donde no se requiere resistencia adicional a impactos o cambios de temperatura, como ventanas interiores, puertas de cristal, o paneles divisorios. 

###  Materiales, Equipos y Herramientas 

  * Paneles de vidrio simple crudo de las dimensiones adecuadas. 
  * Herrajes y accesorios de montaje compatibles con el tipo de estructura. 
  * Herramientas manuales y eléctricas para el corte y ajuste del vidrio. 
  * Equipos de elevación y transporte para manipular los paneles de vidrio con seguridad. 
  * Ingenieros civiles y/o arquitectos para la supervisión y planificación. 
  * Personal técnico especializado en la manipulación e instalación de vidrio simple. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal (EPP). 



###  Procedimiento 

Se inicia con la evaluación del área donde se instalará o sustituirá el vidrio simple crudo. Se verifica la integridad estructural de la abertura y se toman las medidas necesarias para garantizar un ajuste preciso del nuevo panel de vidrio. 

Posteriormente, se procede con el corte del vidrio simple crudo según las dimensiones requeridas, utilizando herramientas especializadas para garantizar bordes limpios y seguros. 

Una vez preparado el vidrio, se lleva a cabo la instalación o sustitución en la abertura correspondiente. Esto implica la aplicación de selladores y adhesivos adecuados para asegurar una fijación firme y duradera. 

Finalmente, se realiza una inspección detallada para verificar la correcta instalación del vidrio y su integridad estructural. Se realizan ajustes finos según sea necesario para garantizar un acabado impecable y un funcionamiento óptimo. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la manipulación y la instalación de vidrio simple crudo. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por el vidrio instalado o sustituido durante la ejecución del proyecto. Esto incluirá todas las áreas de vidrio manipuladas, independientemente de sus dimensiones específicas. El pago se efectuará según la cantidad de metros cuadrados de vidrio tratados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
