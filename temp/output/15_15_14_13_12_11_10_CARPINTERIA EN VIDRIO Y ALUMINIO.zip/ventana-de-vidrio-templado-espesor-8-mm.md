##  Ventana de Vidrio Templado Espesor 8 mm 

###  Definición 

La actividad consiste en la instalación de ventanas de vidrio templado con un grosor de 8 mm. Estas ventanas se utilizan para proporcionar iluminación natural, ventilación y aislamiento acústico en edificaciones residenciales, comerciales e industriales. 

###  Materiales, Equipos y Herramientas 

  * Vidrio templado de 8 mm de espesor. 
  * Perfiles de aluminio o PVC para el marco de la ventana. 
  * Selladores y adhesivos especiales para la fijación del vidrio y los perfiles. 
  * Herramientas manuales y eléctricas para el corte y manipulación del vidrio y los perfiles. 
  * Equipo de elevación y transporte para manipular el vidrio con seguridad. 
  * Herramientas de medición y nivelación para garantizar la precisión en la instalación. 
  * Ingenieros civiles y/o arquitectos para la supervisión y planificación. 
  * Personal técnico especializado en la instalación de ventanas de vidrio templado. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal (EPP). 



###  Procedimiento 

Se inicia con la toma de medidas precisas del hueco donde se instalará la ventana, asegurando un ajuste perfecto y una distribución equitativa de los paneles de vidrio. 

Posteriormente, se procede con el corte y pulido del vidrio templado según las dimensiones especificadas, utilizando herramientas y técnicas adecuadas para garantizar bordes lisos y seguros. 

Una vez preparados los paneles de vidrio, se procede con la instalación de los perfiles de aluminio o PVC en el hueco, asegurando su nivelación y alineación. Los paneles de vidrio se fijan a los perfiles utilizando selladores y adhesivos especiales, garantizando una unión sólida y duradera. 

Finalmente, se realizan ajustes finos para asegurar que la ventana esté correctamente instalada y funcione correctamente, asegurando un cierre hermético y un funcionamiento suave de los mecanismos de apertura y cierre. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la instalación de ventanas de vidrio templado. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de las ventanas de vidrio templado, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por las ventanas instaladas, considerando todas las superficies de vidrio utilizadas en el proyecto. El pago se efectuará según la cantidad de metros cuadrados de vidrio tratados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
