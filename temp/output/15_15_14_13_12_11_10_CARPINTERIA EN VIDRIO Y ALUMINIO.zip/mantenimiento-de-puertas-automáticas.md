##  Mantenimiento de Puertas Automáticas 

###  Definición 

El mantenimiento de puertas automáticas comprende una serie de tareas destinadas a garantizar el correcto funcionamiento y la seguridad de las puertas automáticas instaladas en edificaciones comerciales, industriales o residenciales. Este servicio incluye la revisión del motor, del sistema eléctrico, la limpieza de rieles, el engrasado de rodamientos, el centrado de paños y la revisión de la chapa. 

###  Materiales, Equipos y Herramientas 

  * Lubricantes y grasas especiales para rodamientos y mecanismos de puertas. 
  * Componentes eléctricos de repuesto (interruptores, fusibles, cables, etc.). 
  * Productos de limpieza y desengrasantes. 
  * Elementos de fijación y sujeción (tornillos, tuercas, arandelas). 
  * Herramientas manuales (llaves, destornilladores, alicates). 
  * Multímetro para pruebas eléctricas. 
  * Lubricadores manuales o automáticos. 
  * Escaleras portátiles. 
  * Equipos de protección personal (EPP) 
  * Técnicos especializados en mantenimiento de puertas automáticas. 
  * Electricistas para la revisión del sistema eléctrico. 
  * Personal de apoyo para tareas de limpieza y engrasado. 



###  Procedimiento 

El procedimiento inicia con una inspección visual de la puerta automática para identificar cualquier daño, desgaste o mal funcionamiento. Se procederá a revisar el motor y el sistema eléctrico, verificando conexiones, interruptores, fusibles y la integridad de los cables. Se realizarán pruebas operativas para garantizar su correcto funcionamiento. 

Luego, se limpiarán los rieles y se eliminarán residuos, polvo y suciedad que puedan afectar el desplazamiento de la puerta. Se engrasarán los rodamientos y mecanismos móviles para reducir el desgaste y mejorar la suavidad del movimiento. Se verificará el centrado de los paños y se ajustarán según sea necesario para evitar rozamientos y desgastes prematuros. 

Finalmente, se revisará y ajustará la chapa de cierre para garantizar un cierre seguro y adecuado de la puerta. Se realizarán pruebas finales para verificar que todos los componentes funcionen correctamente y se emitirá un informe detallado del trabajo realizado. 

El contratista es responsable de garantizar el cumplimiento de todas las normas de seguridad, supervisión y regulaciones aplicables durante el desarrollo de la actividad. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar el mantenimiento de puertas automáticas, la unidad de medida será global, es decir, se pagará por el servicio completo de mantenimiento de cada puerta. El pago se efectuará de acuerdo con los términos y condiciones del contrato establecido con el contratista, basado en el alcance de trabajo completado y la aprobación por parte del supervisor de proyecto de EMBOL S.A. 
