##  Ventanas Abatibles en Carpintería de Aluminio y Vidrio Laminado o Templado Dimensiones 2.00 x 2.00 m 

###  Definición 

La actividad consiste en el diseño, provisión e instalación de ventanas abatibles en carpintería de aluminio con vidrio laminado o templado, de dimensiones 2.00 x 2.00 metros. Este proceso incluye la toma de medidas, selección de materiales, provisión de los marcos y hojas abatibles, y su instalación completa en el lugar especificado. La elección de vidrio laminado o templado dependerá de las especificaciones técnicas y normativas de seguridad del proyecto. 

###  Materiales, Equipos y Herramientas 

  * Perfiles de aluminio (aleación 6063 T5 o equivalente) anodizados o pintados. 
  * Vidrio laminado de seguridad o vidrio templado de 10 mm. 
  * Herrajes y accesorios: bisagras abatibles, manillas, cerraduras, juntas de estanqueidad, y tornillería inoxidable. 
  * Herramientas de corte y mecanizado para aluminio: sierras de corte, fresadoras. (si es necesario) 
  * Herramientas de corte y pulido de vidrio: cortavidrios, lijadoras. (si es necesario) 
  * Equipos de sujeción y ensamblaje: taladros, destornilladores eléctricos, remachadoras. 
  * Equipos de medición: cintas métricas, niveles láser. 
  * Equipos de protección personal (EPP): guantes de trabajo, gafas de seguridad, casco, calzado de seguridad. 
  * Equipos para trabajos en altura (si se requiere): andamios certificados, arneses, líneas de vida, escaleras. 
  * Ingenieros civiles y arquitectos para supervisión y diseño. 
  * Técnicos especializados en carpintería de aluminio y vidrio. 
  * Asistentes y operarios para tareas de apoyo y logística. 



###  Procedimiento 

El procedimiento comienza con una visita al sitio para la evaluación y toma de medidas exactas, supervisada por ingenieros civiles y arquitectos. Este paso es crucial para asegurar que las ventanas se ajusten perfectamente a las aberturas especificadas y cumplen con los requisitos del proyecto. 

Una vez obtenidas las medidas, se procede a la selección de los perfiles de aluminio y el tipo de vidrio (laminado o templado) según las especificaciones técnicas y normativas de seguridad. Los perfiles de aluminio se cortan y mecanizan en el taller para formar los marcos y hojas abatibles. Simultáneamente, el vidrio se corta a las dimensiones necesarias y se revisa para asegurar que no haya defectos. 

En el taller, se ensamblan los marcos de aluminio y se fijan las hojas abatibles con los herrajes adecuados. Se instalan las juntas de estanqueidad y se realiza un ajuste preliminar para garantizar que todas las piezas encajen correctamente. Los componentes terminados se preparan para el transporte al sitio de instalación. 

En el sitio de instalación, se prepara el área, asegurando que las superficies donde se montarán las ventanas estén limpias y niveladas. Se instalan los marcos de aluminio, fijándolos firmemente a la estructura del edificio mediante anclajes y tornillería adecuada. Posteriormente, se colocan las hojas abatibles de vidrio en los marcos y se aseguran con bisagras y otros herrajes. 

Se realiza un ajuste final y pruebas de funcionamiento para asegurar que las ventanas operan correctamente y cumplen con los estándares de seguridad y calidad. La limpieza final y la verificación del acabado completan la instalación. 

El contratista es responsable de hacer cumplir todas las normas de seguridad y supervisar al personal en todas las etapas del proyecto. Además, debe asegurarse de que todas las actividades cumplan con las normativas vigentes aplicables a la fabricación e instalación de ventanas. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de ventanas abatibles en carpintería de aluminio y vidrio laminado o templado, la unidad de medida será el metro cuadrado (m²). Se calculará el área total de las ventanas instaladas, considerando las dimensiones exactas de cada unidad. El pago se efectuará según la cantidad de metros cuadrados instalados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. La medición incluirá todas las áreas de ventanas instaladas dentro del alcance del proyecto, independientemente de su forma o tamaño específico. 

El pago se basará en el área efectiva de las ventanas instaladas y verificada por el supervisor de proyecto de EMBOL S.A. 
