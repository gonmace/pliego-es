##  Randas Esmeril en Vidrio 

###  Definición 

La actividad consiste en la colocación de randas esmeriladas en superficies de vidrio previamente instaladas. Este trabajo incluye la preparación de la superficie del vidrio, la aplicación precisa de las randas esmeriladas y el acabado final para asegurar una adherencia duradera y un aspecto uniforme. El objetivo principal es mejorar la privacidad y la estética de los espacios interiores mediante el uso de estas franjas esmeriladas. 

###  Materiales, Equipos y Herramientas 

  * Randa esmerilada pre-cortada con las especificaciones y dimensiones acordadas. 
  * Solución de limpieza sin residuos (agua destilada y detergente suave). 
  * Solución de aplicación para vinilo o película (mezcla de agua y jabón). 
  * Rociadores para la aplicación de soluciones de limpieza y adhesión. 
  * Espátulas de goma (squeegees) para alisar las randas esmeriladas. 
  * Cuchillas y cortadores de precisión para ajustes finos en las randas. 
  * Paños de microfibra para limpieza y secado. 
  * Escaleras y plataformas móviles (si es necesario para trabajos en altura). 
  * Equipos de protección personal (EPP): guantes de trabajo, gafas de seguridad, casco, calzado de seguridad. 
  * Andamios certificados, arneses, líneas de vida (si se requiere trabajar en altura). 
  * Técnicos especializados en la aplicación de películas decorativas en vidrio. 
  * Ayudantes de instalación. 
  * Supervisor de calidad 



###  Procedimiento 

Se inicia con una evaluación exhaustiva de las superficies de vidrio para asegurar que estén limpias y sin defectos que puedan afectar la adherencia de las randas esmeriladas. La limpieza de las superficies de vidrio se lleva a cabo con una solución de agua destilada y detergente suave para eliminar cualquier suciedad, grasa o residuos. 

Una vez limpias y secas, las superficies de vidrio se marcan con precisión utilizando herramientas de medición y cinta adhesiva para definir las áreas exactas donde se aplicarán las randas esmeriladas. Las randas esmeriladas se cortan previamente a las dimensiones requeridas, con un margen de ajuste para garantizar un acabado perfecto. 

La aplicación de las randas esmeriladas comienza con la pulverización de una solución de aplicación (mezcla de agua y jabón) sobre el vidrio y el reverso adhesivo de las randas. Esto permite ajustar y posicionar las randas con precisión antes de fijarlas permanentemente. Las espátulas de goma se utilizan para alisar las randas esmeriladas desde el centro hacia los bordes, eliminando cualquier burbuja de aire o exceso de solución, garantizando una adhesión uniforme. 

Tras la aplicación, se realizan cortes de precisión en los bordes para asegurar un ajuste perfecto y se revisan todos los detalles para asegurar que las randas estén libres de imperfecciones. Se deja secar completamente, verificando la adherencia y apariencia final. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y cumpla con todas las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar todo el proceso para garantizar que se cumplan los estándares de calidad especificados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de colocación de randas esmeriladas en vidrio, la unidad de medida será el metro lineal (ml). Se calculará la longitud total de las randas esmeriladas aplicadas en todas las superficies de vidrio durante la ejecución del proyecto. 

La medición considerará la cantidad de metros lineales de randas esmeriladas colocadas, teniendo en cuenta la precisión del corte y ajuste del material. El pago se efectuará según la cantidad de metros lineales de randas esmeriladas aplicadas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en la longitud efectiva de randas esmeriladas y la aprobación del supervisor de proyecto de EMBOL S.A. 
