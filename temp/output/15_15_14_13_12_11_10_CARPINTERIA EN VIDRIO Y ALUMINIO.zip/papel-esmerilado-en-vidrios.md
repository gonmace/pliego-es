##  Papel Esmerilado en Vidrios 

###  Definición 

La actividad consiste en la colocación de papel esmerilado en superficies de vidrio, con el objetivo de mejorar la privacidad y la estética de los espacios interiores. El papel esmerilado será aplicado de manera precisa y uniforme para asegurar una adhesión duradera y una apariencia homogénea. 

###  Materiales, Equipos y Herramientas 

  * Papel esmerilado pre-cortado según las especificaciones y dimensiones requeridas. 
  * Solución de limpieza sin residuos (agua destilada y detergente suave). 
  * Solución de aplicación para vinilo o película (mezcla de agua y jabón). 
  * Rociadores para la aplicación de soluciones de limpieza y adhesión. 
  * Espátulas de goma (squeegees) para alisar el papel esmerilado. 
  * Cuchillas y cortadores de precisión para ajustes finos en el papel esmerilado. 
  * Paños de microfibra para limpieza y secado. 
  * Escaleras y plataformas móviles (si es necesario para trabajos en altura). 
  * Equipos de protección personal (EPP): guantes de trabajo, gafas de seguridad, casco, calzado de seguridad. 
  * Andamios certificados, arneses, líneas de vida (si se requiere trabajar en altura). 
  * Técnicos especializados en la aplicación de películas decorativas en vidrio. 
  * Ayudantes de instalación. 
  * Supervisor de calidad 



###  Procedimiento 

El procedimiento comienza con una inspección minuciosa de las superficies de vidrio para asegurar que estén limpias y libres de defectos que puedan comprometer la adherencia del papel esmerilado. Se procede a la limpieza de las superficies con una solución de agua destilada y detergente suave para eliminar cualquier suciedad, grasa o residuos. 

Una vez limpias y secas, las superficies de vidrio se marcan con precisión utilizando herramientas de medición y cinta adhesiva para definir las áreas exactas donde se aplicará el papel esmerilado. El papel esmerilado se corta previamente a las dimensiones requeridas, con un margen de ajuste para garantizar un acabado perfecto. 

La aplicación del papel esmerilado comienza con la pulverización de una solución de aplicación (mezcla de agua y jabón) sobre el vidrio y el reverso adhesivo del papel. Esto permite ajustar y posicionar el papel con precisión antes de fijarlo permanentemente. Las espátulas de goma se utilizan para alisar el papel esmerilado desde el centro hacia los bordes, eliminando cualquier burbuja de aire o exceso de solución, asegurando una adhesión uniforme. 

Tras la aplicación, se realizan cortes de precisión en los bordes para asegurar un ajuste perfecto y se revisan todos los detalles para asegurar que el papel esté libre de imperfecciones. Se deja secar completamente, verificando la adherencia y apariencia final. 

El contratista es responsable de hacer cumplir todas las normas de seguridad, asegurando que el personal utilice los equipos de protección personal adecuados y cumpla con todas las regulaciones vigentes aplicables a esta actividad. Además, deberá supervisar todo el proceso para garantizar que se cumplan los estándares de calidad especificados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de colocación de papel esmerilado en vidrios, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por el papel esmerilado aplicado en todas las superficies de vidrio durante la ejecución del proyecto. 

Esto incluirá todas las áreas cubiertas por el papel esmerilado, independientemente de su forma o dimensiones específicas. La medición considerará la cantidad de metros cuadrados de papel esmerilado colocado, teniendo en cuenta la precisión del corte y ajuste del material. El pago se efectuará según la cantidad de metros cuadrados de papel esmerilado aplicado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este se basará en el avance y la aprobación del supervisor de proyecto de EMBOL S.A. 
