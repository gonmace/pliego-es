##  Puertas de Vidrio Templado Espesor 10 mm 

###  Definición 

Implica la colocación de puertas fabricadas con vidrio templado de 10 mm de espesor en aberturas preexistentes. Estas puertas, diseñadas para abrirse y cerrarse de manera abatible, proporcionan una solución estética y funcional para espacios interiores y exteriores. El proceso incluye la manipulación cuidadosa del vidrio templado y la fijación segura de los herrajes necesarios para garantizar su correcto funcionamiento. 

###  Materiales, Equipos y Herramientas 

  * Puertas de vidrio templado de 10 mm de espesor. 
  * Herrajes y accesorios de alta calidad para la instalación. 
  * Sellador y adhesivos específicos para vidrio. 
  * Herramientas manuales y eléctricas para el corte y ajuste preciso del vidrio. 
  * Equipos de elevación y transporte para manipular las puertas de vidrio de manera segura. 
  * Ingenieros civiles y/o arquitectos para la planificación y supervisión. 
  * Personal técnico especializado en la instalación de puertas de vidrio templado. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal (EPP) 



###  Procedimiento 

Se inicia con una inspección detallada del área donde se realizará la instalación, verificando que las aberturas estén debidamente preparadas y niveladas. Luego, se procede con el corte preciso del vidrio templado de acuerdo con las dimensiones requeridas para cada puerta. 

Una vez cortado, el vidrio se limpia y se prepara para la instalación de los herrajes y accesorios necesarios. Estos se fijan con precisión, asegurando un ajuste perfecto y un funcionamiento suave de las puertas. 

Finalmente, se lleva a cabo una inspección exhaustiva para verificar la correcta instalación y funcionamiento de cada puerta. Se realizan ajustes finos según sea necesario para garantizar un acabado impecable. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la manipulación y la instalación de vidrio templado. 

EMBOL se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de Puertas de Vidrio Templado de 10 mm Abatible, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por las puertas instaladas durante la ejecución del proyecto. Esto incluirá todas las puertas colocadas en las aberturas designadas, independientemente de sus dimensiones específicas. El pago se efectuará según la cantidad de metros cuadrados de vidrio templado instalado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
