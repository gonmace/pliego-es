##  Puerta de Vidrio Templado Espesor 10 mm Dimensiones 0.90 x 2.10 m 

###  Definición 

La actividad consiste en la instalación de una puerta de vidrio templado corrediza con un grosor de 10.00 mm y dimensiones de 0.90 metros de ancho por 2.10 metros de alto. Este tipo de puerta se utiliza comúnmente en espacios interiores y exteriores donde se requiere una entrada elegante y resistente, permitiendo el paso de la luz y proporcionando un diseño moderno y funcional. 

###  Materiales, Equipos y Herramientas 

  * Puerta de vidrio templado con las dimensiones especificadas. 
  * Sistema de rieles y herrajes para la instalación corrediza. 
  * Selladores y adhesivos adecuados para la fijación del vidrio. 
  * Herramientas manuales y eléctricas para el montaje y ajuste. 
  * Equipos de elevación y transporte para manipular la puerta de vidrio con seguridad. 
  * Ingenieros civiles y/o arquitectos para la supervisión y planificación. 
  * Personal técnico especializado en la instalación de puertas de vidrio templado. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal (EPP) 



###  Procedimiento 

Se inicia con la preparación del área donde se instalará la puerta, asegurando que la estructura esté lista y en condiciones adecuadas para soportar el peso y las dimensiones del vidrio. 

Posteriormente, se procede con el montaje de los rieles y herrajes necesarios para la instalación corrediza de la puerta. Se verifica que los rieles estén nivelados y alineados correctamente para un funcionamiento suave. 

Una vez preparados los rieles, se coloca el panel de vidrio templado en su posición correspondiente. Se asegura el vidrio utilizando los selladores y adhesivos adecuados, garantizando una fijación firme y segura. 

Finalmente, se realizan ajustes finos para asegurar un funcionamiento óptimo de la puerta, asegurando que se deslice suavemente y que cierre herméticamente. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la instalación de puertas de vidrio templado. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de instalación de la Puerta de Vidrio Templado Corrediza, la unidad de medida será la pieza. Se tomará en cuenta la cantidad de puertas utilizadas, El pago se efectuará según la cantidad puertas instaladas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
