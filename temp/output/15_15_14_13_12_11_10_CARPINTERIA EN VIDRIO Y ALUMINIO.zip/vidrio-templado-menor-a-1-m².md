##  Vidrio Templado Menor a 1 m² 

###  Definición 

Consiste en la instalación o sustitución de paneles de vidrio templado en aberturas o estructuras arquitectónicas, donde el área del vidrio a ser intervenida sea menor a 1 metro cuadrado. 

###  Materiales, Equipos y Herramientas 

  * Paneles de vidrio templado de dimensiones adecuadas. 
  * Herrajes y accesorios de montaje compatibles con el tipo de estructura. 
  * Sellador y adhesivos específicos para vidrio. 
  * Herramientas manuales y eléctricas para el corte y ajuste del vidrio. 
  * Equipos de elevación y transporte para manipular los paneles de vidrio con seguridad. 
  * Ingenieros civiles y/o arquitectos para la supervisión y planificación. 
  * Personal técnico especializado en la manipulación e instalación de vidrio templado. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal. 



###  Procedimiento 

El proceso inicia con la evaluación del área donde se instalará o sustituirá el vidrio templado. Se verifica la integridad estructural de la abertura y se toman las medidas necesarias para garantizar un ajuste preciso del nuevo panel de vidrio. 

Posteriormente, se procede con el corte del vidrio templado según las dimensiones requeridas, utilizando herramientas especializadas para garantizar bordes limpios y seguros. 

Una vez preparado el vidrio, se lleva a cabo la instalación o sustitución en la abertura correspondiente. Esto implica la aplicación de selladores y adhesivos adecuados para asegurar una fijación firme y duradera. 

Finalmente, se realiza una inspección detallada para verificar la correcta instalación del vidrio y su integridad estructural. Se realizan ajustes finos según sea necesario para garantizar un acabado impecable y un funcionamiento óptimo. 

El contratista es responsable de supervisar todo el proceso, asegurando el cumplimiento de las normas de seguridad y calidad establecidas para la actividad. Además, es fundamental cumplir con todas las normativas vigentes relacionadas con la manipulación y la instalación de vidrio templado. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

la unidad de medida será la "pieza". Se contabilizará el número total de paneles de vidrio instalados o sustituidos durante la ejecución del proyecto. El pago se efectuará según la cantidad de piezas de vidrio templado tratadas, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
