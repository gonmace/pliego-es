##  Perfiles de Aluminio Pesado 

###  Definición 

La actividad implica la instalación o desmontaje de elementos estructurales de aluminio diseñados para soportar cargas considerables, según las necesidades del proyecto en cuestión. Esto incluye la manipulación, transporte, y eventual colocación o retirada de estos perfiles siguiendo los lineamientos de seguridad y calidad establecidos. 

###  Materiales, Equipos y Herramientas 

  * Perfiles de aluminio pesado según las especificaciones del diseño. 
  * Elementos de fijación adecuados. 
  * Equipo de elevación y transporte (si aplica). 
  * Herramientas manuales y eléctricas para montaje o desmontaje. 
  * Equipo de medición para garantizar la precisión en la instalación o retiro. 
  * Ingenieros civiles y/o estructurales. 
  * Personal técnico especializado en la manipulación de perfiles de aluminio. 
  * Personal de apoyo para logística y seguridad. 
  * Equipo de protección personal. 



###  Procedimiento 

El procedimiento sigue una serie de pasos meticulosos para garantizar la seguridad y la precisión en la ejecución del proyecto. Comienza con una planificación detallada y una preparación exhaustiva del área de trabajo. Esto implica una revisión minuciosa del diseño y las especificaciones técnicas, así como la adquisición y almacenamiento de todos los materiales y herramientas necesarios para la tarea. 

Una vez que el área de trabajo está debidamente preparada y asegurada, se procede con la manipulación cuidadosa de los perfiles de aluminio. Es fundamental utilizar las herramientas adecuadas y seguir los procedimientos recomendados para evitar daños tanto a los elementos estructurales como a los trabajadores involucrados. Durante este proceso, se presta especial atención a la alineación, nivelación y ajuste de los perfiles para garantizar su correcta instalación o retiro. 

A lo largo de toda la actividad, se lleva a cabo un estricto control de calidad que incluye inspecciones visuales para detectar posibles defectos o irregularidades. Este control garantiza que los perfiles de aluminio estén instalados o retirados de manera adecuada y cumplan con los estándares de calidad requeridos por el proyecto. 

Es responsabilidad del contratista hacer cumplir todas las normas de seguridad pertinentes y asegurarse de que el personal involucrado cumpla con las regulaciones vigentes en el área de construcción y manipulación de materiales. Esto incluye el uso apropiado del equipo de protección personal y el cumplimiento de las normativas locales e internacionales para garantizar la integridad estructural y la seguridad del personal. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La unidad de medida será el metro lineal (m). Se calculará la longitud total de perfiles instalados o retirados durante la ejecución del proyecto. Esto incluirá todas las secciones de perfiles manipulados, independientemente de su forma o dimensiones específicas. El pago se efectuará según la cantidad de metros lineales de perfiles tratados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
