##  Colocado de piso de Pavik peatonal H=0.03 M. (incluye compactado, nivelado, bordes, areneado) 

###  Descripción 

La actividad consiste en la instalación de piso de PAVIK peatonal con un espesor de 0.03 metros. Este procedimiento incluye las etapas de compactación del sustrato, nivelación precisa, instalación de bordes y el areneado final para asegurar la estabilidad y alineación de las piezas. Este tipo de pavimento es ideal para áreas peatonales debido a su durabilidad y estética agradable. 

###  Materiales, herramientas y equipo 

  * PAVIK peatonal. 
  * Arena de relleno. 
  * Material para bordes, como bordillos o perfiles de contención. 
  * Compactadora para asegurar una base sólida. 
  * Palas, trowels y llanas para la distribución y nivelación de la arena. 
  * Cortadoras para ajustar los PAVIK a los bordes y esquinas. 
  * Cascos, guantes, gafas de seguridad, y botas. 
  * Verificación de la certificación de cualquier equipo mayor como compactadoras y cortadoras de pavimento. 



###  Procedimiento 

Inicialmente, se preparará la base sobre la que se asentará el PAVIK, lo que incluye la excavación y compactación del suelo a un grado óptimo de compactación. Se realizará una verificación de la nivelación del terreno utilizando herramientas de precisión como niveles láser. 

Posteriormente, se colocarán los bordes o perfiles de contención, asegurándose de que estén bien fijados y alineados, ya que actuarán como guía y soporte para los bloques de PAVIK. Se esparcirá una capa de arena fina sobre la base compactada, nivelándola cuidadosamente para recibir los pavimentos. 

La instalación del PAVIK se realizará siguiendo un patrón predefinido, comenzando desde una esquina y avanzando hacia el lado opuesto para asegurar la alineación y nivelación. Una vez colocados los bloques, se realizará un areneado adicional, esparciendo arena sobre el piso instalado y barriendo para que penetre en todas las juntas, asegurando la estabilidad y reduciendo el movimiento de las piezas. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), calculando el área total efectivamente cubierta por el piso de PAVIK. El pago se efectuará basándose en los metros cuadrados completados y aceptados, conforme a las especificaciones técnicas y el avance aprobado por EMBOL. 
