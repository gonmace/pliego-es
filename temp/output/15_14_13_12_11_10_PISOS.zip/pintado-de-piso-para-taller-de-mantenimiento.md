##  Pintado de piso para taller de mantenimiento 

###  Descripción 

La actividad de pintado de piso para el taller de mantenimiento involucra el retiro y lijado del piso existente en mal estado utilizando discos abrasivos, seguido del amolado del piso para asegurar una superficie nivelada y libre de imperfecciones. Finalmente, se aplicarán tres capas de pintura de uretano con color liso, con un espesor total de 4 mm. Este procedimiento está diseñado para preparar un piso duradero y resistente, capaz de soportar alto tráfico y las exigencias de un entorno industrial. 

###  Materiales, herramientas y equipo 

  * Discos abrasivos de alta resistencia 
  * Pintura de uretano de alta resistencia (color liso, 4 mm de espesor) 
  * Primer adecuado para pintura de uretano 
  * Thiner para preparación y limpieza 
  * Materiales de sellado y reparación de grietas 
  * Amoladoras de piso 
  * Lijadoras de piso con discos abrasivos 
  * Equipos de aplicación de pintura (compresores, pistolas de pintura, rodillos) 
  * Herramientas de corte y preparación de superficie 
  * Equipos de protección personal (EPP): cascos, guantes, gafas de seguridad, botas con punta de acero, mascarillas respiratorias, chalecos reflectantes 
  * Ingenieros civiles 
  * Arquitectos 
  * Supervisores de seguridad 
  * Operadores de maquinaria especializada 
  * Trabajadores especializados en preparación de superficies y aplicación de pintura industrial 
  * Personal de apoyo logístico 



###  Procedimiento 

El procedimiento de pintado de piso par talleres de mantenimiento comenzará con la preparación del área de trabajo, asegurando que la zona esté delimitada y señalizada correctamente para proteger tanto al personal como a las áreas circundantes. 

El primer paso será el retiro del piso existente en mal estado, utilizando amoladoras de piso y lijadoras con discos abrasivos de alta resistencia. Este proceso asegurará la eliminación de cualquier material suelto y la nivelación de la superficie, proporcionando una base adecuada para el siguiente paso. Durante esta fase, se realizarán inspecciones periódicas para asegurar que el piso se esté preparando adecuadamente. 

A continuación, se procederá con el amolado del piso utilizando amoladoras para garantizar una textura uniforme y adecuada para la adherencia de la pintura de uretano. Cualquier grieta o imperfección encontrada durante esta fase será reparada utilizando materiales de sellado adecuados. 

Con la superficie completamente preparada, se aplicará una capa de primer para garantizar una mejor adhesión de la pintura de uretano. Este primer será seleccionado específicamente para ser compatible con la pintura de uretano y el tipo de tráfico esperado en el taller de mantenimiento. 

La aplicación de la pintura de uretano se realizará en tres capas. Cada capa será aplicada utilizando equipos de aplicación de pintura adecuados, como compresores y pistolas de pintura, asegurando una cobertura uniforme y un espesor total de 4 mm. Entre cada capa, se permitirá el tiempo de secado adecuado según las especificaciones del fabricante de la pintura. La última capa proporcionará un acabado liso y resistente, apto para alto tráfico. 

Durante todo el proceso, se implementarán medidas de control de calidad para verificar que la aplicación de la pintura cumpla con los estándares especificados. El contratista es responsable de hacer cumplir las normas de seguridad, supervisión y todas las normativas vigentes referentes a esta actividad. 

EMBOL se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de pintado de piso para taller de mantenimiento, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por el trabajo realizado durante la ejecución del proyecto. Esto incluirá todas las áreas tratadas y pintadas con precisión, abarcando la totalidad del espacio destinado para este propósito, independientemente de su forma o dimensiones específicas. 

La medición considerará la cantidad de metros cuadrados cubiertos por el retiro, lijado, amolado y la aplicación de las tres capas de pintura de uretano, teniendo en cuenta la complejidad del trabajo y la cantidad de materiales utilizados. El pago se efectuará según la cantidad de metros cuadrados de trabajo realizado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
