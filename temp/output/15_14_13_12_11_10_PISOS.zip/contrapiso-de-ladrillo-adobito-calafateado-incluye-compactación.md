##  Contrapiso de ladrillo adobito calafateado (incluye compactación) 

###  Descripción 

Esta actividad implica la preparación y construcción de un contrapiso utilizando ladrillos de adobito, que serán calafateados y compactados adecuadamente para proporcionar una base sólida y nivelada para futuras instalaciones o acabados de piso. Este tipo de contrapiso es esencial para garantizar la durabilidad y la integridad estructural de los pisos que se instalarán encima. 

###  Materiales, herramientas y equipo 

  * Ladrillos de adobito. 
  * Mortero o cal para el calafateo. 
  * Arena y grava para la base de compactación. 
  * Compactadora para asegurar una base sólida. 
  * Palas, picos y carretillas para la manipulación de materiales. 
  * Cascos, guantes, gafas de seguridad y botas con puntera de acero. 



###  Procedimiento 

Inicialmente, se preparará el sitio asegurando que el terreno esté limpio y nivelado. Se realizará la compactación del suelo utilizando maquinaria adecuada para crear una base firme. Sobre esta base se distribuirán los ladrillos de adobito, colocándolos de forma precisa y alineada. 

Posteriormente, se procederá a calafatear los espacios entre los ladrillos utilizando una mezcla de mortero o cal, que se aplicará cuidadosamente para evitar huecos o áreas débiles en el contrapiso. Cada etapa del proceso se verificará utilizando niveles para asegurar que la superficie sea completamente plana y uniforme. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), basándose en la superficie total efectivamente construida del contrapiso de ladrillo adobito calafateado. La verificación se llevará a cabo por un inspector de EMBOL S.A., quien confirmará que las dimensiones y la calidad del trabajo cumplen con los estándares especificados. El pago se efectuará conforme a la cantidad de metros cuadrados completados y verificados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este pago se basará en el avance del proyecto y la aprobación final por parte de EMBOL S.A., asegurando que el trabajo cumpla con todas las expectativas de calidad y eficiencia. 
