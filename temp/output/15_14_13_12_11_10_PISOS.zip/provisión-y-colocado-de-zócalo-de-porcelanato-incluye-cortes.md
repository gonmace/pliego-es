##  Provisión Y Colocado De Zócalo De Porcelanato (Incluye Cortes) 

###  Descripción 

Esta actividad comprende la provisión y colocación de zócalos de porcelanato, incluyendo los cortes necesarios para adaptarlos a las dimensiones específicas de las áreas designadas. Los zócalos de porcelanato proporcionan un acabado estético y funcional, protegiendo las intersecciones entre las paredes y los pisos y facilitando la limpieza y mantenimiento. 

###  Materiales, herramientas y equipo 

  * Materiales: Zócalos de porcelanato, adhesivo para porcelanato, masilla o sellador de juntas. 
  * Equipos: Cortadora de porcelanato para realizar cortes precisos, mezcladora para adhesivos. 
  * Herramientas: Metro, nivel, espátula, llana dentada, cortador manual de azulejos, amoladora con disco de diamante para ajustes finos. 
  * Personal: Incluirá instaladores especializados en cerámica, un supervisor técnico, y personal de apoyo general. 
  * EPP: Cascos, guantes de seguridad, gafas de protección, y calzado de seguridad. 



###  Procedimiento 

El procedimiento inicia con la preparación de la superficie, asegurando que las paredes estén niveladas y limpias. Se medirá el perímetro a cubrir para determinar la cantidad necesaria de zócalos y planificar los cortes. La instalación se realizará aplicando adhesivo sobre la parte posterior del zócalo y fijándolo a lo largo de la base de la pared, utilizando un nivel para asegurar la alineación correcta. Los cortes se realizarán con la cortadora de porcelanato, cuidando de obtener un acabado limpio y adecuado a las esquinas y terminaciones. 

Se recomienda revisar la adhesión de los zócalos en varios puntos durante la instalación para asegurar una fijación uniforme. Además, podría ser beneficioso utilizar técnicas de sellado entre los zócalos y el piso para evitar la acumulación de humedad y suciedad, mejorando así la durabilidad y la higiene del área instalada. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros lineales, considerando la longitud total de zócalo porcelanato colocado a lo largo de las paredes. Esta medición incluirá todos los cortes y ajustes realizados, asegurando que se contabilice solo el material efectivamente instalado y adherido de manera correcta. El pago se efectuará según la longitud de zócalo instalada y verificada, conforme a los términos del contrato establecido con el contratista, y se ajustará según el avance y la aprobación final de EMBOL S.A. 
