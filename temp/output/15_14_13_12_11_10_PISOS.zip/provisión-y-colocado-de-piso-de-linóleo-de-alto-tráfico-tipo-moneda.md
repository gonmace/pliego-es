##  Provisión y colocado de piso de linóleo de alto tráfico (tipo moneda) 

###  Descripción 

La actividad consiste en la provisión y colocación de piso de linóleo de alto tráfico tipo moneda. Esta actividad está diseñada para proporcionar un revestimiento de suelo duradero y resistente en áreas de alto tránsito. El linóleo tipo moneda se caracteriza por su superficie texturizada que ofrece mayor resistencia al deslizamiento y facilidad de mantenimiento. 

###  Materiales, herramientas y equipo 

  * Piso de linóleo tipo moneda, adhesivo específico para linóleo, nivelador. 
  * Cortadora de piso, rodillo pesado para asegurar la adherencia. 
  * Espátulas, rodillos, y escuadras. 
  * Profesionales incluirán instaladores especializados y un supervisor de obra. El equipo de apoyo incluirá ayudantes generales. 
  * Cascos, guantes, gafas de seguridad, y calzado de seguridad. 



###  Procedimiento 

El procedimiento para la instalación del piso de linóleo tipo moneda comienza con la preparación adecuada de la superficie, asegurando que esté limpia, seca y nivelada. Posteriormente, se procederá a medir y cortar el linóleo de acuerdo a las dimensiones requeridas. Se aplicará el adhesivo recomendado por el fabricante de manera uniforme sobre la superficie. El linóleo se colocará cuidadosamente sobre el adhesivo, utilizando rodillos pesados para eliminar burbujas de aire y asegurar una adhesión completa. Los bordes se recortarán para un ajuste perfecto y se realizará una inspección final para asegurar que no hay defectos visibles ni imperfecciones en la instalación. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición del piso de linóleo instalado se realizará en metros cuadrados (m²), tomando en cuenta el área total efectivamente cubierta por el linóleo, incluyendo cortes y adaptaciones necesarias en el sitio. El pago se efectuará de acuerdo con los términos y condiciones del contrato establecido con el contratista y se basará en la cantidad de metros cuadrados de piso de linóleo efectivamente instalados y aprobados por EMBOL S.A. La aprobación final y el pago estarán condicionados al avance y a los estándares de calidad y conformidad con las especificaciones técnicas establecidas.Principio del formulario 
