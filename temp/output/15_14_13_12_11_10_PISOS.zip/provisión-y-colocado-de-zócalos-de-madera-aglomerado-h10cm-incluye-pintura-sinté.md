##  Provisión y colocado de zócalos de madera / aglomerado h=10cm (incluye pintura sintética lavable) 

###  Descripción 

Esta actividad implica la provisión y colocación de zócalos de madera o aglomerado con una altura de 10 cm, incluyendo la aplicación de pintura sintética lavable. Estos zócalos servirán para proteger y decorar la parte inferior de las paredes interiores, además de facilitar la limpieza y el mantenimiento. 

###  Materiales, herramientas y equipo 

  * Materiales: Zócalos de madera o aglomerado, pintura sintética lavable, imprimante, masilla para madera. 
  * Equipos: Sierra de mesa o sierra circular, mezcladora para pintura. 
  * Herramientas: Cepillos, rodillos, brochas, espátula, lija, nivel. 
  * Personal: Carpinteros, pintores, ayudantes y un supervisor técnico. 
  * EPP: Cascos, guantes, gafas de seguridad, máscaras para vapores de pintura. 



###  Procedimiento 

Se comenzará con la inspección y preparación de la superficie donde se instalarán los zócalos, asegurando que esté limpia, seca y nivelada. Se medirán y cortarán los zócalos a la medida necesaria, utilizando la sierra de mesa para garantizar cortes precisos. Antes de la instalación, se aplicará imprimante sobre la madera para protegerla y mejorar la adherencia de la pintura. 

La colocación de los zócalos se realizará aplicando un adhesivo específico para madera en la parte trasera de cada pieza y fijándolos firmemente contra la pared. Se utilizará masilla para cubrir cualquier imperfección o hueco en las uniones. Una vez instalados y fijados los zócalos, se procederá a pintarlos con la pintura sintética lavable, aplicando las capas necesarias para alcanzar un acabado uniforme y duradero. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros lineales, considerando la longitud total de los zócalos efectivamente provistos y colocados. Esto incluirá todas las piezas, independientemente de las dimensiones de cada corte realizado. El pago se realizará según la cantidad de metros lineales instalados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. El pago final se basará en la verificación del trabajo completado a satisfacción y la aprobación por parte de EMBOL S.A. 
