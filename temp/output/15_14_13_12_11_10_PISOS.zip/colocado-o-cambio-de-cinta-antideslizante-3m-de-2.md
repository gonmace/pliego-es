##  Colocado o cambio de cinta antideslizante (3m de 2”) 

###  Descripción 

Esta actividad consiste en el colocado o reemplazo de cinta antideslizante de la marca 3M con un ancho de 2 pulgadas. El propósito es mejorar la seguridad en las superficies donde el riesgo de deslizamiento es alto, tales como escaleras, pasillos y áreas de trabajo que requieren tránsito seguro para evitar accidentes. 

###  Materiales, herramientas y equipo 

  * Materiales: Cinta antideslizante 3M de 2 pulgadas. 
  * Herramientas: Escoba, paños de limpieza, alcohol o desengrasante, cortador o tijeras. 
  * Personal: Técnicos en seguridad industrial, ayudantes. 
  * EPP: Guantes de seguridad, gafas de protección. 



###  Procedimiento 

Se debe iniciar asegurándose de que la superficie donde se colocará la cinta antideslizante esté completamente limpia, seca y libre de grasa. Utilizar desengrasante o alcohol para eliminar cualquier residuo que pueda comprometer la adherencia de la cinta. 

Medir y cortar la cinta antideslizante a la longitud deseada, asegurándose de que cada pieza se ajuste perfectamente al área de aplicación sin superposiciones innecesarias. Retirar el respaldo adhesivo y aplicar la cinta firmemente sobre la superficie, comenzando desde un extremo y presionando hacia el otro para evitar burbujas de aire. 

Es crucial verificar la alineación y el nivel de la cinta durante su aplicación para garantizar que la superficie quede completamente segura y funcional. Examinar todas las juntas y asegurarse de que estén firmemente selladas y lisas. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros lineales, considerando la longitud total de cinta antideslizante que ha sido efectivamente colocada o reemplazada. 

El pago se realizará de acuerdo con la cantidad de metros lineales instalados, conforme a los términos y condiciones del contrato establecido con el contratista. Este se efectuará basándose en el avance físico del trabajo y tras la aprobación final de EMBOL S.A., asegurando que la instalación cumpla con todas las especificaciones técnicas y de seguridad requeridas. 
