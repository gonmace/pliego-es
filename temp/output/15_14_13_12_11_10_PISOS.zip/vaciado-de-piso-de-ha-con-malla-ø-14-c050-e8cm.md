##  Vaciado de piso de H°A° con malla Ø 1/4” C/0.50, e=8cm 

###  Descripción 

El vaciado de piso de hormigón armado con malla de acero Ø 1/4” C/0.50, con un espesor de 8 cm, es una actividad constructiva destinada a la creación de una superficie sólida y durable. Este proceso implica la preparación del terreno, la colocación de una malla de acero como refuerzo y el posterior vaciado de hormigón, lo que resulta en una base robusta y adecuada para soportar cargas significativas en edificaciones industriales, comerciales o residenciales. 

###  Materiales, herramientas y equipo 

  * Hormigón de alta resistencia. 
  * Malla de acero Ø 1/4” C/0.50. 
  * Hormigonera para mezclar el hormigón. 
  * Vibrador de hormigón para eliminar burbujas de aire y asegurar compacidad. 
  * Regla vibratoria para nivelar la superficie del hormigón. 
  * Palas, cucharas de albañil y carretillas. 
  * Espátulas y llanas para acabados superficiales. 
  * Casco, guantes de seguridad, gafas de protección, botas de seguridad. 



###  Procedimiento 

El proceso inicia con la preparación del subsuelo, que debe estar bien compactado y nivelado para evitar asentamientos futuros. Se colocará una capa de grava o piedra triturada para mejorar la drenabilidad y se compactará nuevamente. 

La malla de acero será cuidadosamente dispuesta sobre el área de trabajo, asegurando que cada intersección esté correctamente atada y que la malla cubra completamente el área designada, manteniendo una separación homogénea del suelo. 

El hormigón será mezclado en la hormigonera, asegurando una consistencia adecuada que permita una buena trabajabilidad pero manteniendo la resistencia especificada. Este será vertido sobre la malla, y se utilizará una regla vibratoria para esparcir y nivelar el hormigón, mientras que un vibrador de hormigón se empleará para compactar y eliminar las burbujas de aire, asegurando una integración completa entre la malla y el hormigón. 

El acabado de la superficie se realizará utilizando llanas y técnicas de alisado para lograr la textura deseada. Una vez finalizado, el hormigón requerirá un proceso de curado, que deberá seguir las recomendaciones del fabricante para asegurar la máxima resistencia y durabilidad del material. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), tomando en cuenta la superficie efectivamente cubierta por el hormigón armado. La verificación del área tratada se realizará mediante mediciones post-vaciado, confirmadas por supervisores de EMBOL S.A. El pago se basará en la superficie verificada y se ajustará a los términos del contrato establecido con el contratista, dependiendo del avance y la aprobación de EMBOL S.A. 
