##  Provisión y colocado de piso antideslizante de goma 

###  Descripción 

La actividad involucra la provisión y colocación de piso antideslizante de goma, destinado a áreas donde se requiera seguridad adicional contra resbalones, como zonas húmedas o de alto tráfico. Este tipo de piso mejora la tracción y reduce los riesgos de accidentes, siendo ideal para espacios industriales, comerciales y públicos. 

###  Materiales, herramientas y equipo 

  * Piso de goma antideslizante, adhesivo específico para goma, cinta métrica, y nivelador. 
  * Cortadora de rollo de goma, rodillo para asegurar la adherencia. 
  * Espátulas, cuchillas para cortar goma, reglas largas. 
  * Incluirá instaladores especializados, un supervisor técnico y personal de apoyo para manejo de materiales. 
  * Todos los involucrados deben utilizar cascos, guantes de trabajo, gafas de seguridad y zapatos de seguridad. 



###  Procedimiento 

La instalación comienza con la preparación de la superficie, asegurándose de que está limpia, seca y libre de imperfecciones. Medir el área a cubrir y cortar el piso de goma de acuerdo con las dimensiones y formas necesarias. Aplicar el adhesivo de manera uniforme sobre la superficie preparada y colocar el piso de goma cuidadosamente, utilizando un rodillo pesado para facilitar la adhesión efectiva y eliminar cualquier burbuja de aire. Las juntas entre las piezas de goma se sellarán adecuadamente para evitar levantamientos y asegurar un acabado uniforme y seguro. Es vital verificar la alineación y el nivel durante la colocación para evitar errores que comprometan la funcionalidad y estética del piso. 

Considerando la importancia de la seguridad, se recomienda evaluar la adhesión del piso bajo diferentes condiciones ambientales para asegurar su durabilidad y funcionalidad a largo plazo. Además, se debe prestar especial atención a las zonas de transición entre diferentes tipos de piso para garantizar una superficie continua sin riesgos de tropiezo. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), considerando el área total efectivamente cubierta por el piso antideslizante de goma. El cálculo incluirá todas las piezas cortadas y colocadas, asegurando que se mida exactamente lo instalado. El pago se efectuará según los metros cuadrados instalados conforme a los términos y condiciones del contrato establecido con el contratista, basándose en el progreso y la aprobación final de EMBOL S.A. La calidad del trabajo y la adherencia a las especificaciones técnicas serán inspeccionadas antes de la aprobación final. 
