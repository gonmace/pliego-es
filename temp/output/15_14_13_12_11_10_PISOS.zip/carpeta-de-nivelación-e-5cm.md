##  Carpeta de nivelación e= 5cm 

###  Descripción 

La actividad consiste en la aplicación de una carpeta de nivelación de 5 cm de espesor, que se emplea para corregir irregularidades en superficies existentes y prepararlas para revestimientos finales o adicionales. Este proceso es crucial para asegurar una base uniforme y sólida para la instalación de pisos, azulejos, o cualquier otro acabado superficial. 

###  Materiales, herramientas y equipo 

  * Hormigón de fraguado rápido, adecuado para capas delgadas. 
  * Aditivos para mejorar la adherencia y la manejabilidad del hormigón. 
  * Mezcladoras de hormigón para asegurar una mezcla homogénea. 
  * Niveladoras y reglas para distribuir y nivelar la carpeta de manera uniforme. 
  * Palas, llanas y trowels para la aplicación manual donde sea necesario. 
  * Medidores de nivel y reglas láser para controlar la planitud y uniformidad de la carpeta. 
  * Cascos, gafas de seguridad, guantes de trabajo, botas con puntera de acero. 



###  Procedimiento 

El área de trabajo se limpiará profundamente para remover cualquier residuo o material que pueda comprometer la adherencia de la carpeta. Se verificará la nivelación existente mediante instrumentos precisos, y se marcarán las áreas que requieren corrección. 

El hormigón se preparará en la mezcladora, siguiendo las proporciones recomendadas por el fabricante, añadiendo los aditivos necesarios para mejorar la fluidez y el tiempo de secado. Una vez lista la mezcla, se verterá sobre la superficie y se esparcirá con reglas y niveladoras, asegurando que se mantenga el espesor de 5 cm en toda la extensión de la superficie. 

Durante el fraguado, se utilizarán llanas para alisar la superficie, eliminando burbujas de aire y asegurando una acabado liso y uniforme. El curado del hormigón se manejará mediante técnicas adecuadas para evitar fisuras y para optimizar la dureza de la superficie. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), basándose en el área total efectivamente cubierta por la carpeta de nivelación. El pago se efectuará según los metros cuadrados finalizados y aceptados por la supervisión de EMBOL S.A., conforme a los términos del contrato. El proceso de medición tomará en cuenta la uniformidad y calidad del acabado, y el pago se basará en el avance y la aprobación final de EMBOL. 
