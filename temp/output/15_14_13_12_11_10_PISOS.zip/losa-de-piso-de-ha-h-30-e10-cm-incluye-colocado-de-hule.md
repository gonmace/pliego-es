##  Losa de piso de H°A° H-30, e=10 cm (incluye colocado de hule) 

###  Descripción 

La actividad consiste en la construcción de un piso de losa de hormigón armado (H°A°) con un espesor de 10 cm, utilizando hormigón H30. El proceso incluye la preparación del terreno mediante nivelado y compactado, con la provisión de material para una base de 15 cm de espesor. La losa se reforzará con parrillas de acero de 6 mm colocadas cada 15 cm, y se emplearán caballetes de acero de 10 mm y barras de transmisión de acero de 20 mm colocadas cada 40 cm. Además, se incorporará la provisión y colocación de hule de 200 micrones y el corte y sellado de juntas con Sikaflex para asegurar la durabilidad y funcionalidad del piso. 

###  Materiales, herramientas y equipo 

  * Hormigón H30 
  * Parrillas de acero de 6 mm (cada 15 cm) 
  * Caballetes de acero de 10 mm (15 unidades) 
  * Barras de transmisión de acero de 20 mm (cada 40 cm) 
  * Hule de 200 micrones 
  * Sikaflex para sellado de juntas 
  * Material de relleno para base (15 cm de espesor) 
  * Maquinaria de compactación (rodillos vibratorios, placas compactadoras) 
  * Equipos de nivelación 
  * Herramientas de corte y doblado de acero 
  * Hormigoneras y equipos de bombeo de hormigón 
  * Equipos de vibrado para compactación del hormigón 
  * Herramientas de colocación de hule y sellado de juntas 
  * Equipos de protección personal (EPP): cascos, guantes, gafas de seguridad, botas con punta de acero, chalecos reflectantes 
  * Ingenieros civiles 
  * Arquitectos 
  * Supervisores de seguridad 
  * Operadores de maquinaria pesada 
  * Trabajadores especializados en colocación de hormigón armado 
  * Personal de apoyo logístico 



###  Procedimiento 

El procedimiento comenzará con la preparación del terreno, que incluye la nivelación y compactación de la superficie destinada para el piso de losa. Utilizando maquinaria de compactación adecuada, se asegurará una base sólida y uniforme. Posteriormente, se procederá con la provisión y colocación del material de relleno para una base de 15 cm de espesor, compactándolo en capas sucesivas hasta alcanzar la densidad requerida. 

Una vez preparada la base, se colocará el hule de 200 micrones sobre toda la superficie, asegurando que esté bien extendido y sin arrugas. Esto proporcionará una barrera contra la humedad y otros agentes externos. 

La siguiente etapa involucra la instalación de las parrillas de acero de 6 mm, las cuales serán posicionadas y aseguradas con caballetes de acero de 10 mm, colocados a intervalos regulares para mantener la altura y alineación correcta de la armadura. Además, se instalarán barras de transmisión de acero de 20 mm cada 40 cm, aseguradas y sostenidas adecuadamente para garantizar la transferencia de cargas entre secciones de la losa. 

El vaciado del hormigón H30 se realizará utilizando hormigoneras y equipos de bombeo, vertiendo el hormigón sobre la armadura de acero en capas uniformes. Durante el vaciado, se emplearán equipos de vibrado para asegurar la eliminación de burbujas de aire y la compactación adecuada del hormigón. Una vez vertido y nivelado el hormigón, se procederá con el acabado superficial. 

Después del fraguado inicial del hormigón, se realizarán los cortes para las juntas de dilatación según las especificaciones del diseño. Las juntas serán selladas utilizando Sikaflex, asegurando la durabilidad y funcionalidad del piso de losa de hormigón armado. 

Durante todo el proceso, se implementarán medidas de control de calidad para verificar que cada etapa cumpla con los estándares especificados. El contratista es responsable de hacer cumplir las normas de seguridad, supervisión y todas las normativas vigentes referentes a esta actividad. 

EMBOL se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

Para medir y pagar la actividad de construcción del piso de losa de hormigón armado, la unidad de medida será el metro cuadrado (m²). Se calculará el área total cubierta por la losa de hormigón armado realizada durante la ejecución del proyecto. Esto incluirá todas las áreas niveladas, compactadas, armadas y vaciadas con precisión, abarcando la totalidad del espacio destinado para este propósito, independientemente de su forma o dimensiones específicas. 

La medición considerará la cantidad de metros cuadrados cubiertos por la losa de hormigón armado, teniendo en cuenta la preparación del terreno, colocación del hule, instalación de la armadura y la aplicación de hormigón. El pago se efectuará según la cantidad de metros cuadrados de trabajo realizado, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Se basará en el avance y la aprobación por parte de EMBOL S.A. 
