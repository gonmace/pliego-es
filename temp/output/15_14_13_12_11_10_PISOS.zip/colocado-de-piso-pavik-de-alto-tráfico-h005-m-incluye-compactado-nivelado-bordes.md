##  Colocado de piso Pavik de alto tráfico h=0.05 m. (incluye compactado, nivelado, bordes, areneado) 

###  Descripción 

La actividad consiste en la instalación de piso PAVIK diseñado para soportar alto tráfico con un espesor de 0.05 metros. Este proceso incluye la preparación del suelo, compactación, nivelación, instalación de bordes y el areneado final, adecuado para zonas con alta frecuencia de tránsito peatonal o vehicular ligero. 

###  Materiales, herramientas y equipo 

  * PAVIK de alto tráfico. 
  * Arena de relleno de calidad asegurada para soporte y filtración. 
  * Bordillos o perfiles metálicos para contención. 
  * Compactadoras y rodillos para garantizar una base firme. 
  * Niveles láser y equipos topográficos para asegurar la correcta nivelación. 
  * Palas, trowels para esparcir y nivelar la arena. 
  * Cortadoras de precisión para adaptar los PAVIK según diseño. 
  * Cascos, guantes de trabajo, gafas de seguridad, y botas robustas. 



###  Procedimiento 

El proceso inicia con la preparación del terreno, que debe ser excavado y nivelado a la profundidad requerida. Posteriormente, se compacta la base para proporcionar un soporte sólido y evitar asentamientos futuros. 

Se procederá a instalar los bordillos o perfiles metálicos que servirán de delimitación y contención para los bloques PAVIK, asegurándose de que estos elementos estén correctamente alineados y fijados. Sobre la base compactada, se extenderá una capa de arena que será nivelada meticulosamente. 

La colocación de los PAVIK se realizará de forma sistemática, comenzando desde un extremo asegurando el alineamiento y la planimetría correcta en cada paso. Una vez colocados, se rellenarán las juntas con arena fina, y se procederá al areneado intensivo para llenar todos los espacios intersticiales, aumentando así la interlock entre las unidades. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición del trabajo realizado se efectuará en metros cuadrados (m²), considerando el área efectivamente cubierta por el pavimento PAVIK. El pago se realizará basado en la superficie terminada y aceptada según las especificaciones del contrato y sujeto a la aprobación de EMBOL basándose en la inspección y el avance del proyecto. 
