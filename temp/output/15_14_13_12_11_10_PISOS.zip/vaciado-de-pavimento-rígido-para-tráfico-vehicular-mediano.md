##  Vaciado De Pavimento Rígido Para Tráfico Vehicular Mediano 

###  Descripción 

Esta actividad comprende el vaciado de pavimento rígido diseñado para soportar tráfico vehicular mediano. El objetivo es proporcionar una superficie de rodadura resistente y duradera, adecuada para vehículos en áreas de tránsito moderado dentro de las instalaciones de EMBOL. Este pavimento será construido utilizando hormigón de alta resistencia, con especificaciones adecuadas para soportar cargas vehiculares y condiciones ambientales específicas. 

###  Materiales, herramientas y equipo 

  * Materiales: Hormigón premezclado de alta resistencia, acero de refuerzo, formas de madera o metal, selladores de juntas. 
  * Equipos: Camión mezclador, bomba de hormigón, compactadora, vibrocompactador, niveladora. 
  * Herramientas: Palas, talochas, cortadoras de concreto, reglas, niveles, cintas métricas. 
  * Personal: Ingenieros civiles, operadores de maquinaria pesada, técnicos en construcción, ayudantes generales. 
  * EPP: Cascos, guantes, gafas de seguridad, botas de seguridad. 



###  Procedimiento 

Iniciar con la preparación del terreno, que incluye la limpieza, nivelación y compactación del subsuelo. Proceder con la colocación de formas y la instalación de acero de refuerzo según los diseños estructurales. 

Verter el hormigón premezclado en el sitio, asegurándose de que se distribuya uniformemente y llenar todas las formas preparadas. Utilizar vibradores de concreto para eliminar las burbujas de aire y asegurar una compactación adecuada, lo que es crucial para la durabilidad del pavimento. 

Nivelar el hormigón utilizando talochas y reglas. Permitir que el hormigón cure correctamente, aplicando métodos de curado estándar como membranas de curado o riego constante para mantener la humedad. 

Realizar cortes de dilatación para controlar la contracción y expansión del hormigón. Estos cortes ayudan a prevenir grietas no controladas. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago se realizará en metros cúbicos (m³), basándose en el volumen de hormigón utilizado en la construcción del pavimento, medido desde el camión mezclador hasta las formas completadas. 

El pago se efectuará de acuerdo con el volumen de hormigón colocado y aceptado en el sitio, siguiendo los términos del contrato establecido con el contratista. Este pago se basará en los informes de avance y será finalizado tras la aprobación de EMBOL, asegurando que el pavimento cumpla con todas las especificaciones técnicas y estándares de calidad. 
