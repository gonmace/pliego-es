##  Colocado de piso de cerámica/porcelanato (incluye cemento cola) 

###  Descripción 

La actividad consiste en la instalación de piso de cerámica o porcelanato utilizando cemento cola, diseñado para interiores o exteriores dependiendo de las especificaciones del área designada. Esta tarea incluye la preparación de la superficie, aplicación de adhesivo, colocación de losetas, rejuntado y limpieza final. 

###  Materiales, herramientas y equipo 

  * Losetas de cerámica o porcelanato. 
  * Cemento cola adecuado para el tipo de loseta y condiciones de la superficie. 
  * Mortero de juntas para el rejuntado. 
  * Cortadora de loseta para ajustes precisos. 
  * Espátulas dentadas y llanas para la aplicación de cemento cola. 
  * Crucetas para mantener la alineación y uniformidad de las juntas. 
  * Mezclador de mortero eléctrico. 
  * Guantes de seguridad, gafas de protección, rodilleras y mascarillas. 
  * Revisión y certificación de equipos de corte y mezclado, cumpliendo con las normativas vigentes. 



###  Procedimiento 

El proceso inicia con la preparación de la superficie, que debe estar limpia, nivelada y libre de humedad. Aplicar una imprimación si es necesario para mejorar la adherencia del cemento cola. 

La mezcla del cemento cola se realizará según las indicaciones del fabricante, asegurando una consistencia homogénea. Usando la llana dentada, aplicar el adhesivo sobre la superficie trabajando en secciones pequeñas para evitar que se seque antes de la colocación de las losetas. 

Colocar las losetas de cerámica o porcelanato comenzando desde el centro hacia los bordes de la habitación, utilizando crucetas para garantizar espacios uniformes. Las losetas deben ser presionadas firmemente en su lugar y ajustadas para evitar desniveles. 

Una vez que el adhesivo haya curado, se procederá al rejuntado de las juntas, eligiendo un color de mortero que complemente las losetas. Después del tiempo de secado recomendado por el fabricante, realizar una limpieza final para remover residuos de mortero y pulir la superficie. 

EMBOL se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para fines de pago se realizará en metros cuadrados (m²), basándose en el área efectivamente cubierta por las losetas de cerámica o porcelanato. El pago se ajustará de acuerdo con las especificaciones contractuales y estará sujeto a la inspección final y aprobación de EMBOL, asegurando que se cumplen todas las especificaciones y estándares de calidad. 
