##  Acera De Cemento e=5 cm 

###  Descripción 

La actividad consiste en la construcción de una acera de cemento con un espesor de 5 cm. Este tipo de infraestructura está diseñada para proporcionar un camino seguro y duradero para el tránsito peatonal en las instalaciones de la planta. La acera será construida utilizando técnicas y materiales específicos que garanticen su funcionalidad y longevidad. 

###  Materiales, herramientas y equipo 

  * Materiales: Cemento Portland, arena, grava, agua, y mallazo de refuerzo si es necesario. 
  * Equipos: Mezcladora de concreto, vibradora de concreto. 
  * Herramientas: Palas, nivel, reglas, cortadora de concreto, carretillas, cintas métricas, moldes o formas. 
  * Personal: Ingenieros civiles, operarios de construcción, ayudantes. 
  * EPP: Cascos, guantes de trabajo, gafas de seguridad, botas con puntera de acero. 



###  Procedimiento 

Comenzar con la preparación del sitio, asegurando que la superficie esté nivelada y compactada adecuadamente. Seguir con la colocación de formas o moldes que definirán los límites y la forma de la acera. 

Preparar la mezcla de concreto en la proporción correcta utilizando cemento, arena, grava y agua. Verificar la consistencia del concreto para asegurar una buena trabajabilidad y durabilidad. Verter el concreto en las formas preparadas, utilizando técnicas de vibrado para eliminar las burbujas de aire y asegurar una superficie uniforme y compacta. 

Nivelar el concreto con reglas y alisar la superficie con llanas. Permitir que el concreto cure adecuadamente, aplicando métodos de curado como el riego regular o la utilización de compuestos de curado para prevenir la evaporación rápida del agua. 

Retirar las formas una vez que el concreto haya alcanzado suficiente dureza y realizar los cortes de contracción para controlar las fisuras. Limpiar el área y asegurar la disposición adecuada de los residuos generados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados, basándose en la superficie total efectivamente construida conforme a las especificaciones técnicas. 

El pago se efectuará de acuerdo con la cantidad de metros cuadrados de acera de cemento completados, siguiendo los términos y condiciones del contrato establecido con el contratista. El pago final estará condicionado al avance y aprobación de EMBOL S.A., asegurando que la construcción cumpla con todos los estándares de calidad y seguridad. 
