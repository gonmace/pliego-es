##  Vaciado de carpeta de hormigón fibrado 

###  Descripción 

El vaciado de carpeta de hormigón fibrado es un proceso constructivo que implica la preparación de una mezcla de hormigón reforzada con fibras, destinada a mejorar la resistencia a la tracción y la durabilidad del pavimento. Este tipo de hormigón es ideal para áreas que requieren una mayor resistencia al impacto y a la fatiga, como son las zonas de alto tráfico o carga pesada. La actividad abarca desde la preparación del sitio hasta el acabado final de la superficie de hormigón. 

###  Materiales, herramientas y equipo 

  * Hormigón premezclado de alta calidad. 
  * Fibras de polipropileno o acero, según especificaciones del proyecto. 
  * Camión hormigonera para el transporte y mezcla. 
  * Bomba de hormigón para un vaciado eficiente. 
  * Regla vibratoria y vibradores de hormigón para asegurar un compactado adecuado. 
  * Palas, trowels, y llanas para esparcir y nivelar el hormigón. 
  * Cascos, guantes de seguridad, gafas de protección, y botas de seguridad. 



###  Procedimiento 

Inicialmente, se realizará una evaluación del terreno para asegurar que está adecuadamente compactado y nivelado. Posteriormente, se procederá a la instalación de encofrados que delimitarán la zona de vaciado, asegurando que estos sean resistentes y estén correctamente alineados. 

El hormigón fibrado se mezclará en el camión hormigonera, asegurando una distribución uniforme de las fibras dentro de la mezcla. La mezcla será transportada al sitio de vaciado mediante una bomba de hormigón, lo cual permite un colocación precisa y eficiente, especialmente en áreas amplias o de difícil acceso. 

Durante el vaciado, se utilizarán vibradores para asegurar que el hormigón se compacte correctamente, eliminando bolsas de aire y asegurando un contacto íntimo con el encofrado y la armadura. La regla vibratoria se empleará para nivelar la superficie del hormigón, seguido de un proceso de alisado con llanas para obtener la textura deseada. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cúbicos (m³), basándose en el volumen total de hormigón fibrado utilizado en el vaciado. Esta medición será verificada mediante registros de entrega del hormigón y controles durante el proceso de vaciado. El pago se realizará conforme a los metros cúbicos efectivamente colocados y aceptados por la supervisión de EMBOL S.A., de acuerdo con los términos y condiciones del contrato establecido. El avance y la aprobación de EMBOL son cruciales para la finalización del pago. 
