##  Reparación de piso de cerámica / porcelanato (incluye cemento cola) 

###  Descripción 

La actividad implica la reparación de áreas dañadas de pisos de cerámica o porcelanato, utilizando cemento cola para la colocación de nuevas losetas. Este proceso incluye la remoción de las piezas dañadas, preparación de la superficie, y la colocación y ajuste de nuevas losetas para asegurar la continuidad estética y funcional del piso. 

###  Materiales, herramientas y equipo 

  * Losetas de cerámica o porcelanato que coincidan con las existentes en color, tamaño y textura. 
  * Cemento cola adecuado para cerámica/porcelanato. 
  * Mortero para juntas, compatible con el color existente. 
  * Herramientas de corte para cerámica/porcelanato, como cortadoras de disco húmedo. 
  * Niveladores láser para asegurar la alineación y nivelación adecuada. 
  * Martillos, cinceles y espátulas para remover las losetas dañadas. 
  * Llanas dentadas para aplicar el cemento cola. 
  * Crucetas para asegurar el espaciado uniforme de las juntas. 
  * Cascos, gafas de seguridad, guantes de trabajo, y mascarillas. 
  * Todos los equipos de corte y mezclado deberán contar con certificación actualizada, asegurando su adecuado mantenimiento y funcionamiento seguro. 



###  Procedimiento 

El procedimiento comienza con la identificación y evaluación de las áreas dañadas. Se procederá a la cuidadosa remoción de las losetas dañadas, limpiando completamente la superficie de escombros y asegurando que esté nivelada y libre de impurezas. 

Se preparará el cemento cola según las especificaciones del fabricante y se aplicará en la superficie preparada. Las nuevas losetas serán colocadas con precisión, usando crucetas para mantener la uniformidad en el espaciado de las juntas, asegurando que la colocación esté alineada con las losetas existentes. Después de permitir el tiempo adecuado para que el adhesivo se cure, se aplicará el mortero para juntas y se realizará una limpieza final. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago se realizará por pieza, contabilizando cada loseta que ha sido reemplazada o reparada correctamente. El pago se ajustará de acuerdo a los términos y condiciones del contrato y estará sujeto a la inspección y aprobación final de EMBOL, garantizando la conformidad con las especificaciones técnicas y los estándares de calidad establecidos. 
