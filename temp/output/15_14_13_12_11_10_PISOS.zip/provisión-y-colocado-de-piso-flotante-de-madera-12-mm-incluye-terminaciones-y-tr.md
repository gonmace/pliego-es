##  Provisión y colocado de piso flotante de madera 12 mm (incluye terminaciones y transiciones) 

###  Descripción 

Esta actividad comprende la provisión e instalación de piso flotante de madera de 12 mm, incluyendo las terminaciones y transiciones necesarias para una correcta integración con otros tipos de pisos y características arquitectónicas. Se enfoca en proporcionar un acabado estético y funcional, con la resistencia adecuada para el tráfico esperado en el área instalada. 

###  Materiales, herramientas y equipo 

  * Piso flotante de madera de 12 mm. 
  * Materiales para terminaciones y transiciones, como molduras y perfiles de unión. 
  * Capa base aislante para la instalación flotante. 
  * Adhesivos y selladores apropiados para las juntas y bordes. 
  * Sierra de corte para madera, preferiblemente una sierra de inglete para cortes precisos. 
  * Kit de instalación para piso flotante, que incluye espaciadores, bloque de golpeo y barra de tracción. 
  * Nivel láser para verificar la uniformidad de la instalación. 
  * Guantes de seguridad, gafas de protección, mascarillas antipolvo y cascos. 
  * Todo equipo mecánico como sierras y herramientas eléctricas debe tener certificaciones de seguridad y mantenimiento al día. 



###  Procedimiento 

El proceso inicia con la preparación de la superficie, asegurando que esté limpia, seca y nivelada. Se colocará la capa base aislante sobre toda la superficie para proporcionar aislamiento acústico y absorción de la humedad. A continuación, se procederá a la instalación del piso flotante, comenzando desde la esquina más lejana de la entrada principal y avanzando hacia la salida, asegurando que los paneles estén bien bloqueados y alineados. Las terminaciones y transiciones se manejarán con cuidado, utilizando perfiles adecuados para cada tipo de encuentro con otros materiales o cambios de nivel. Cada paso se verificará con herramientas de nivelación para mantener la planeidad y uniformidad. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago se realizará por metro cuadrado, cubriendo la superficie total donde se ha colocado el piso flotante. El cálculo incluirá todas las áreas completadas, sin importar la complejidad de las terminaciones o las características especiales de las transiciones. El pago se efectuará según la cantidad de metros cuadrados completados y será conforme a los términos del contrato, basándose en el progreso y aprobación de las etapas por parte de EMBOL S.A. 
