##  Vaciado de carpeta de nivelación + sika sobre losa con pendiente adecuada hacia drenaje (espesor mínimo 0.04m) 

###  Descripción 

La actividad implica el vaciado de una carpeta de hormigón de nivelación con un espesor mínimo de 0.04 metros, con adición de Sika, sobre una losa existente con pendiente adecuada para facilitar el drenaje. Esta capa es crucial para asegurar una superficie uniforme y funcional que dirija efectivamente el agua hacia áreas de drenaje designadas, evitando acumulaciones y posibles deterioros estructurales. 

###  Materiales, herramientas y equipo 

  * Hormigón preparado específico para capas delgadas de nivelación. 
  * Aditivo Sika para mejorar la adhesión y resistencia al agua. 
  * Otros aditivos según especificaciones del fabricante de Sika. 
  * Mezcladoras de concreto para garantizar una mezcla homogénea. 
  * Nivel láser y reglas para asegurar la pendiente correcta y uniformidad del espesor. 
  * Palas, llanas y reglas para esparcir y nivelar la mezcla de hormigón. 
  * Mangueras de nivel para verificar la pendiente antes y después del vaciado. 
  * Cascos, gafas de seguridad, mascarillas, guantes y botas de seguridad. 



###  Procedimiento 

Antes de iniciar el vaciado, se realizará una inspección detallada de la losa existente para confirmar la adecuación de la pendiente y la ausencia de daños o impurezas que puedan afectar la adhesión del nuevo hormigón. La superficie se limpiará completamente para eliminar polvo, suciedad o residuos. 

Se preparará la mezcla de hormigón con Sika siguiendo las recomendaciones del fabricante para asegurar la máxima eficacia del aditivo. La mezcla se verterá sobre la losa comenzando desde el punto más alto, extendiéndola cuidadosamente con llanas y asegurándose de mantener el espesor y la pendiente necesarios para un drenaje eficiente. 

Durante el proceso de curado, se tomarán medidas para mantener la humedad adecuada y evitar la evaporación rápida del agua, lo cual podría afectar la integridad de la carpeta. Se realizarán controles regulares para verificar la uniformidad de la pendiente y el espesor durante y después del curado. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), calculando el área total efectivamente cubierta por la carpeta de nivelación. El pago se efectuará basándose en los metros cuadrados completados y aceptados, conforme a las especificaciones técnicas y el avance aprobado por EMBOL. 
