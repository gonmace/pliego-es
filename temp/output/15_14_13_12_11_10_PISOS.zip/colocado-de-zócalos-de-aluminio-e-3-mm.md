##  Colocado de zócalos de aluminio e= 3 mm 

###  Descripción 

La actividad comprende la provisión y colocación de zócalos de aluminio con un espesor de 3 mm. Estos zócalos se instalarán en la parte inferior de las paredes interiores para protegerlas de impactos y desgaste, además de proporcionar un acabado estético y duradero. 

###  Materiales, herramientas y equipo 

  * Materiales: Zócalos de aluminio de 3 mm de espesor, tornillos y anclajes adecuados para aluminio. 
  * Equipos: Sierra de corte para metales, taladro. 
  * Herramientas: nivel láser, escuadra, destornilladores, llave ajustable. 
  * Personal: Instaladores especializados en trabajos con aluminio, ayudantes, y un supervisor técnico. 
  * EPP: Guantes de seguridad, gafas de protección, cascos. 
  * 


###  Procedimiento 

Iniciar con una revisión de las áreas donde se instalarán los zócalos para asegurar que las superficies estén limpias y niveladas. Se medirá la longitud necesaria para los zócalos y se realizarán cortes precisos con una sierra especializada para aluminio. 

La instalación de los zócalos de aluminio se realizará marcando los puntos de fijación en la pared, perforando con el taladro y asegurando cada sección del zócalo con tornillos y anclajes apropiados para garantizar una fijación robusta y alineada. Se verificará el nivel y la alineación continua de los zócalos durante todo el proceso para asegurar una instalación uniforme. 

Es recomendable considerar el uso de selladores en las juntas de los zócalos para prevenir la acumulación de humedad y el posible desprendimiento. Además, es aconsejable realizar una revisión final para asegurar que todos los zócalos estén correctamente instalados y ajustados. 

EMBOL S.A. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros lineales, tomando en cuenta la longitud total de los zócalos de aluminio que han sido efectivamente provistos y colocados. Esto incluirá todos los segmentos instalados, independientemente de las dimensiones individuales de cada pieza. 

El pago se realizará de acuerdo con la cantidad de metros lineales instalados, conforme a los términos y condiciones del contrato establecido con el contratista. Este se efectuará basándose en el avance físico del trabajo y tras la aprobación final de EMBOL S.A., asegurando que la instalación cumpla con todas las especificaciones técnicas y estéticas requeridas. 
