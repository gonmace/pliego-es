##  Contrapiso de empedrado 

###  Descripción 

La actividad de construcción de un contrapiso de empedrado consiste en la creación de una base sólida y uniforme para superficies exteriores o interiores utilizando piedras naturales o artificiales dispuestas meticulosamente y fijadas con un aglutinante como mortero de cemento. Este tipo de contrapiso es ideal para áreas que requieren durabilidad y estética, como patios, caminos peatonales o bases para otras instalaciones. 

###  Materiales, herramientas y equipo 

  * Piedras de tamaño uniforme o irregular según el diseño. 
  * Mortero de cemento o una mezcla de cal y arena. 
  * Arena para la nivelación y compactación. 
  * Compactadora para asegurar la base. 
  * Mezcladora de cemento para preparar el mortero. 
  * Palas, picos y rastrillos para la preparación y nivelación del terreno. 
  * Niveles, metros y cuerdas para alinear y medir. 
  * Cascos, guantes de trabajo, gafas de seguridad, y botas con punta de acero. 



###  Procedimiento 

Inicialmente, se preparará el sitio asegurando que el terreno esté libre de cualquier obstrucción y perfectamente nivelado. Esta nivelación se verifica utilizando herramientas de precisión para asegurar que la base sea uniforme en toda el área de trabajo. 

Posteriormente, se compactará la base utilizando arena y una compactadora para crear una superficie sólida sobre la cual se colocarán las piedras. Las piedras se dispondrán de acuerdo con el diseño preestablecido, asegurando que cada pieza quede bien encajada y nivelada. Las juntas entre las piedras se rellenarán con mortero de cemento, garantizando la estabilidad y durabilidad del contrapiso. 

EMBOL SA. se deslinda de cualquier responsabilidad asociada a la actividad de transporte y disposición de los residuos generados. La empresa contratista es responsable de llevar a cabo la actividad de manera segura y conforme a todas las normativas y regulaciones aplicables. 

###  Medición y Precio 

La medición para el pago de esta actividad se realizará en metros cuadrados (m²), basándose en la superficie total efectivamente cubierta por el contrapiso de empedrado. La verificación de la superficie se llevará a cabo por un inspector de EMBOL S.A., quien confirmará que las dimensiones y la calidad del trabajo cumplen con las especificaciones. El pago se efectuará conforme a la cantidad de metros cuadrados completados y verificados, de acuerdo con los términos y condiciones del contrato establecido con el contratista. Este proceso se basará en el progreso del proyecto y la aprobación final por parte de EMBOL S.A. 
